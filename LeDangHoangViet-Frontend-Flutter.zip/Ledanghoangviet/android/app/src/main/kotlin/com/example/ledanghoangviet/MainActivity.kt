package com.example.ledanghoangviet

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity(), SensorEventListener {
    private var pendingResult: MethodChannel.Result? = null
    private var pendingImage: ByteArray? = null
    private val pickImageRequest = 4102
    private val saveImageRequest = 4103
    private var sensorManager: SensorManager? = null
    private var motionSink: EventChannel.EventSink? = null
    private var sensorRegistered = false
    private var lastSample = 0L

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "attendance/device")
            .setMethodCallHandler { call, result ->
                if (pendingResult != null) {
                    result.error("BUSY", "Một thao tác chọn/lưu ảnh đang mở.", null)
                    return@setMethodCallHandler
                }
                when (call.method) {
                    "pickQrImage" -> {
                        pendingResult = result
                        try {
                            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                type = "image/*"
                                addCategory(Intent.CATEGORY_OPENABLE)
                            }, pickImageRequest)
                        } catch (e: Exception) {
                            pendingResult = null
                            result.error("PICK_FAILED", "Không mở được trình chọn ảnh.", null)
                        }
                    }
                    "saveQrImage" -> {
                        val bytes = call.argument<ByteArray>("bytes")
                        val name = (call.argument<String>("name") ?: "LeDangHoangViet_QR.png")
                            .replace(Regex("[^a-zA-Z0-9_.-]"), "_")
                        if (bytes == null || bytes.isEmpty() || bytes.size > 8 * 1024 * 1024) {
                            result.error("INVALID_IMAGE", "Ảnh QR không hợp lệ.", null)
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            val values = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LeDangHoangViet")
                                put(MediaStore.Images.Media.IS_PENDING, 1)
                            }
                            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            try {
                                requireNotNull(uri)
                                val output = contentResolver.openOutputStream(uri) ?: error("Cannot open output")
                                output.use { it.write(bytes) }
                                contentResolver.update(uri, ContentValues().apply {
                                    put(MediaStore.Images.Media.IS_PENDING, 0)
                                }, null, null)
                                result.success("Pictures/LeDangHoangViet/$name")
                            } catch (e: Exception) {
                                if (uri != null) contentResolver.delete(uri, null, null)
                                result.error("SAVE_FAILED", "Không lưu được ảnh QR.", null)
                            }
                        } else {
                            pendingResult = result
                            pendingImage = bytes
                            try {
                                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                    type = "image/png"
                                    addCategory(Intent.CATEGORY_OPENABLE)
                                    putExtra(Intent.EXTRA_TITLE, name)
                                }, saveImageRequest)
                            } catch (e: Exception) {
                                pendingResult = null
                                pendingImage = null
                                result.error("SAVE_FAILED", "Không mở được trình lưu ảnh.", null)
                            }
                        }
                    }
                    else -> result.notImplemented()
                }
            }
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "attendance/motion")
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    motionSink = events
                    if (sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null) {
                        events?.error("NO_SENSOR", "Thiết bị không có gia tốc kế.", null)
                        motionSink = null
                    } else registerMotion()
                }
                override fun onCancel(arguments: Any?) {
                    motionSink = null
                    unregisterMotion()
                }
            })
    }

    private fun registerMotion() {
        if (sensorRegistered || motionSink == null) return
        val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        lastSample = 0L
        sensorRegistered = sensorManager?.registerListener(this, sensor, 100_000) == true
        if (!sensorRegistered) motionSink?.error("SENSOR_FAILED", "Không mở được gia tốc kế.", null)
    }
    private fun unregisterMotion() {
        sensorManager?.unregisterListener(this)
        sensorRegistered = false
    }
    override fun onSensorChanged(event: SensorEvent) {
        if (event.timestamp - lastSample < 100_000_000L) return
        lastSample = event.timestamp
        motionSink?.success(listOf(event.values[0].toDouble(), event.values[1].toDouble(), event.values[2].toDouble()))
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onPause() { unregisterMotion(); super.onPause() }
    override fun onResume() { super.onResume(); registerMotion() }
    override fun onDestroy() {
        unregisterMotion()
        motionSink = null
        pendingResult?.error("CANCELLED", "Thao tác ảnh đã đóng.", null)
        pendingResult = null
        pendingImage = null
        super.onDestroy()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImageRequest && requestCode != saveImageRequest) return
        val result = pendingResult ?: return
        val bytes = pendingImage
        pendingResult = null
        pendingImage = null
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) { result.success(null); return }
        try {
            if (requestCode == saveImageRequest) {
                val output = contentResolver.openOutputStream(uri) ?: error("Cannot open output")
                output.use { it.write(requireNotNull(bytes)) }
                result.success("Đã lưu ảnh QR")
            } else {
                val target = File(cacheDir, "attendance-qr-import.jpg")
                val input = contentResolver.openInputStream(uri) ?: error("Cannot read image")
                input.use { source -> target.outputStream().use { output ->
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val size = source.read(buffer)
                        if (size < 0) break
                        total += size
                        require(total <= 20 * 1024 * 1024) { "Image exceeds 20 MB" }
                        output.write(buffer, 0, size)
                    }
                } }
                result.success(target.absolutePath)
            }
        } catch (e: Exception) {
            result.error("IMAGE_FAILED", "Không đọc/lưu được ảnh. Chọn ảnh nhỏ hơn 20 MB.", null)
        }
    }
}
