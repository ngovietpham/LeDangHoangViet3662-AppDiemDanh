import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:ledanghoangviet/main.dart';
import 'package:ledanghoangviet/screens/main_screen.dart';
import 'package:ledanghoangviet/utils/api_client.dart';

Finder field(String label) =>
    find.ancestor(of: find.text(label), matching: find.byType(TextFormField));
void main() {
  setUp(() => ApiClient.logout());
  testWidgets('Empty credentials are rejected before sending a request',
      (tester) async {
    var requests = 0;
    ApiClient.client = MockClient((_) async {
      requests++;
      return http.Response('{}', 500);
    });
    await tester.pumpWidget(const MyApp());
    await tester.ensureVisible(find.text('Gửi OTP đăng nhập'));
    await tester.tap(find.text('Gửi OTP đăng nhập'));
    await tester.pump();
    expect(find.text('Nhập tên đăng nhập'), findsOneWidget);
    expect(find.text('Nhập mật khẩu'), findsOneWidget);
    expect(requests, 0);
  });
  for (final role in ['Admin', 'Teacher', 'Student']) {
    testWidgets('OTP login routes $role to its dashboard', (tester) async {
      var requested = false, verified = false;
      ApiClient.client = MockClient((r) async {
        if (r.url.path.endsWith('request-login-otp')) {
          requested = true;
          return http.Response(
              jsonEncode({'message': 'Đã gửi OTP', 'devOtp': '123456'}), 200);
        }
        if (r.url.path.endsWith('/login')) {
          expect(jsonDecode(r.body)['otp'], '123456');
          verified = true;
          return http.Response(
              jsonEncode({
                'token': 'test-token',
                'role': role,
                'user': {'id': 'id1', 'initials': 'Test', 'role': role}
              }),
              200);
        }
        return http.Response('[]', 200);
      });
      await tester.pumpWidget(const MyApp());
      await tester.enterText(field('Tên đăng nhập'), 'test.user');
      await tester.enterText(field('Mật khẩu'), 'Demo@2026!');
      await tester.ensureVisible(find.text('Gửi OTP đăng nhập'));
      await tester.tap(find.text('Gửi OTP đăng nhập'));
      await tester.pumpAndSettle();
      expect(requested, isTrue);
      expect(verified, isFalse);
      expect(ApiClient.token, isNull);
      await tester.enterText(field('OTP 6 chữ số từ email'), '123456');
      await tester.ensureVisible(find.text('Xác thực & đăng nhập'));
      await tester.tap(find.text('Xác thực & đăng nhập'));
      await tester.pumpAndSettle();
      expect(verified, isTrue);
      expect(find.byType(DashboardScreen), findsOneWidget);
      expect(tester.widget<DashboardScreen>(find.byType(DashboardScreen)).role,
          role);
      expect(ApiClient.token, 'test-token');
    });
  }
  test('401 clears session so expired credentials cannot be reused', () async {
    ApiClient.token = 'expired';
    ApiClient.user = {'id': 'x'};
    ApiClient.client =
        MockClient((_) async => http.Response('{"message":"Hết phiên"}', 401));
    await expectLater(
        ApiClient.request('courses'), throwsA(isA<ApiException>()));
    expect(ApiClient.token, isNull);
    expect(ApiClient.user, isNull);
  });
}
