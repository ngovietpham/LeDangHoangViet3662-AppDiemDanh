# Le Dang Hoang Viet — QR, GPS và chuyển động (1.1.0+2)

## Tên dự án
Flutter: ledanghoangviet (thư mục Ledanghoangviet); Android: com.example.ledanghoangviet.
WebAPI: ledanghoangviet3662.csproj; namespace ledanghoangviet3662.
SQLite demo: ledanghoangviet3662.db. SQL Server mẫu: ledanghoangviet3662_db.

## Chạy từ source trên máy khác
1. Cài Flutter tương thích pubspec.lock (bản đã build: Flutter 3.47.7, Dart 3.13.5), Android Studio/SDK/JDK và .NET SDK 10.
2. Giải nén source. Mở thư mục ledanghoangviet3662, chạy Start-Demo.cmd. Script tạo appsettings.json từ mẫu và SQLite có dữ liệu demo; chờ API chạy ở cổng 5300. Lần đầu cần Internet để tải thư viện.
3. Mở thư mục Ledanghoangviet bằng Android Studio, chạy flutter pub get rồi Run trên emulator. Hoặc cài APK kèm theo.
4. Trong cấu hình kết nối ở màn hình đăng nhập: emulator dùng http://10.0.2.2:5300/api/ . Điện thoại thật cùng Wi-Fi dùng http://IP-LAN-laptop:5300/api/ và cần laptop cho phép kết nối tới API.
5. API phải đang chạy trong suốt lúc demo. Tắt hẳn app sẽ cần đăng nhập lại.

## Đăng nhập và tài khoản mới
Tài khoản mẫu: admin.demo, gv.demo, sv.demo. Mật khẩu chung: Demo@2026! . Nhập tên/mật khẩu → Gửi OTP đăng nhập → nhập mã DEMO hiện trong app → Xác thực & đăng nhập.
OTP DEMO chỉ áp dụng email @example.test trong môi trường Development có bật Demo:ExposeOtp.
Đăng ký email thật: cấu hình SMTP trong appsettings.json riêng trước, mở app → Đăng ký sinh viên → nhập thông tin và email nhận thư → Gửi OTP → lấy mã 6 số từ email → hoàn tất đăng ký. Sau đó đăng nhập bằng tên/mật khẩu và OTP email mới. Cùng một API 5300 xử lý cả tài khoản mẫu và email thật. OTP hạn 5 phút, gửi lại sau 60 giây.
Source nộp không chứa mật khẩu SMTP hoặc dữ liệu cá nhân; máy thầy cần tự cấu hình SMTP để gửi email thật.

## Demo QR + GPS trên một emulator
1. Đăng nhập gv.demo, mở lớp MOB101 hoặc lớp mình tạo; ghi danh sv.demo nếu chưa có.
2. Tạo buổi đang diễn ra, giờ bắt đầu trước hiện tại vài phút và kết thúc sau hiện tại. Kiểm tra tọa độ/bán kính lớp.
3. Mở QR buổi học, nhấn Lưu ảnh QR. Ảnh nằm trong Pictures/LeDangHoangViet. Mã có hạn tối đa 120 giây, màn hình tự làm mới; ảnh đã lưu không tự cập nhật.
4. Đăng xuất rồi đăng nhập sv.demo ngay. Mở đúng lớp/buổi → Quét QR & xác thực vị trí.
5. Trên emulator, Extended Controls → Location đặt tọa độ trùng lớp (lớp mẫu: vĩ độ 10.762622, kinh độ 106.660172). Nhấn Lấy vị trí hiện tại.
6. Nhấn Quét QR của giảng viên → Chọn ảnh QR từ thiết bị → chọn ảnh vừa lưu. Nếu hết hạn, giảng viên phải lưu mã mới. Với điện thoại, có thể quét camera mã trên màn hình khác.
7. Xác nhận & gửi điểm danh. Chờ thông báo Đã lưu trên server; mở lịch sử lớp để xem bản ghi. Gửi lại cùng buổi sẽ bị chặn trùng.
8. Đăng nhập giảng viên để xem/điều chỉnh trạng thái điểm danh với lý do. Có thể dùng buổi mới khi muốn quay lại từ đầu.

## Demo cảm biến chuyển động
Đăng nhập bất kỳ vai trò → Công cụ → Đo chuyển động. Máy thật: nghiêng/lắc nhẹ, xem X/Y/Z, biểu đồ, số lần chuyển động và mức biến thiên. Có nút Tạm dừng đo, Tiếp tục đo, Đo lại.
Emulator: Extended Controls → Virtual sensors → Device Pose, thay đổi tư thế/chuyển động. Cảm biến đứng yên sẽ không tự tăng số đếm. Ngưỡng 8 m/s², phải trở về dưới 3 trước lần kế tiếp, cách nhau ít nhất 700 ms.

## Chức năng khác
Admin CRUD tài khoản/lớp học phần, phân công giảng viên. Giảng viên quản lý sinh viên lớp, CRUD buổi học và bản ghi điểm danh. Sinh viên xem lớp, buổi và lịch sử. Server kiểm tra quyền, thành viên, thời gian buổi, QR ký HMAC, thời hạn, vị trí/độ chính xác và chặn trùng.

## Kết quả kiểm tra
48 kiểm tra API, 15 kiểm tra logic Dart đạt; dart analyze lib test tool không có lỗi. APK release 1.1.0+2 đã build và cài trên emulator.
Đã đọc ảnh QR bằng app, lấy GPS, gửi điểm danh thành công và đọc lại bản ghi từ API. Gia tốc kế giả lập đã làm đổi X/Y/Z, đếm hai lần chuyển động; tạm dừng và đặt lại về 0 hoạt động.
Camera emulator chưa đọc được mã; chưa có điện thoại để xác minh camera thật. Không coi mở màn hình camera là đã quét thành công.
Flutter widget test chưa chạy được do tiến trình test lỗi trên Windows; không ghi nhận đạt. SQL Server/migration gốc chưa kiểm thử, demo dùng SQLite riêng.

Source được phát triển tiếp từ dự án hiện có, dùng các thư viện công khai có giấy phép trong vendor. Không bảo đảm tính độc nhất tuyệt đối so với mọi source khác. Đây là bản demo học phần, chưa triển khai production/CH Play.
