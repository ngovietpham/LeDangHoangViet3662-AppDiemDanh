import 'dart:io';
import 'package:ledanghoangviet/models/attendance_qr.dart';
import 'package:ledanghoangviet/models/motion_reading.dart';

int checks = 0;
void check(bool condition, String name) {
  if (!condition) throw StateError(name);
  checks++;
}

void main() {
  final now = DateTime.utc(2026, 10, 21, 14);
  final expiry =
      now.add(const Duration(seconds: 120)).millisecondsSinceEpoch ~/ 1000;
  final signature = List.filled(64, 'A').join();
  final qr = AttendanceQr.tryParse('ATTEND|17|$expiry|$signature');
  check(qr != null, 'A generated QR format must be readable');
  check(qr!.validateFor(17, now) == null, 'Matching live session is accepted');
  check(qr.validateFor(18, now) != null, 'Wrong session is rejected');
  check(qr.validateFor(17, now.add(const Duration(seconds: 120))) != null,
      'Expiry boundary is rejected');
  check(qr.remainingSeconds(now) == 120, 'Countdown starts at two minutes');
  check(AttendanceQr.tryParse('https://example.test') == null,
      'Unrelated QR is rejected');
  check(AttendanceQr.tryParse('ATTEND|17|$expiry|short') == null,
      'Malformed signature is rejected');
  check(AttendanceQr.tryParse('ATTEND|-1|$expiry|$signature') == null,
      'Negative session is rejected');
  final motion = MotionReading();
  for (var i = 0; i < 100; i++) {
    motion.add(i.isEven ? 9.80665 : 0, i.isEven ? 0 : 9.80665, 0,
        now.add(Duration(milliseconds: i * 100)));
  }
  check(motion.shakes == 0,
      'Gravity/orientation changes alone do not count as shaking');
  check(motion.samples.length == 80, 'Chart buffer remains bounded');
  for (var i = 0; i < 30; i++) {
    motion.add(0, 0, 25, now.add(Duration(seconds: 20, milliseconds: i * 100)));
  }
  check(motion.shakes == 1, 'Sustained high acceleration counts once');
  motion.add(0, 0, 9.80665, now.add(const Duration(seconds: 24)));
  motion.add(0, 0, 25, now.add(const Duration(seconds: 25)));
  check(motion.shakes == 2, 'Settling and moving again counts a second shake');
  motion.add(
      0, 0, 9.80665, now.add(const Duration(seconds: 25, milliseconds: 50)));
  motion.add(0, 0, 25, now.add(const Duration(seconds: 25, milliseconds: 100)));
  check(motion.shakes == 2, 'Fast noise is debounced');
  final samples = motion.samples.length;
  motion.add(double.nan, 0, 0, now);
  check(motion.samples.length == samples && motion.peak.isFinite,
      'Invalid sensor values are ignored');
  motion.reset();
  check(motion.shakes == 0 && motion.peak == 0 && motion.samples.isEmpty,
      'Reset clears the measurement');
  stdout.writeln(
      'PASS: $checks QR and motion logic checks. Signature authenticity is checked by the API.');
}
