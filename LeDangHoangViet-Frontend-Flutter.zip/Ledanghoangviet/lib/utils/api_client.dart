import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/config_url.dart';

class ApiException implements Exception {
  final String message;
  final int status;
  ApiException(this.message, [this.status = 0]);
  @override
  String toString() => message;
}

class ApiClient {
  static String? token;
  static Map<String, dynamic>? user;
  static http.Client client = http.Client();
  static Future<dynamic> request(String path,
      {String method = 'GET', Map<String, dynamic>? body}) async {
    try {
      final req = http.Request(method, Uri.parse('${ConfigUrl.baseUrl}$path'));
      req.headers.addAll({
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token'
      });
      if (body != null) req.body = jsonEncode(body);
      final res = await http.Response.fromStream(
              await client.send(req).timeout(const Duration(seconds: 20)))
          .timeout(const Duration(seconds: 20));
      dynamic data;
      try {
        data = res.body.isEmpty ? null : jsonDecode(res.body);
      } catch (_) {
        data = null;
      }
      if (res.statusCode >= 400) {
        if (res.statusCode == 401 && token != null) {
          token = null;
          user = null;
        }
        final message = data is Map ? data['message'] ?? data['title'] : null;
        throw ApiException(
            message?.toString() ??
                (res.statusCode == 403
                    ? 'Bạn không có quyền thực hiện thao tác này.'
                    : res.statusCode == 401
                        ? 'Phiên đăng nhập không hợp lệ. Hãy đăng nhập lại.'
                        : res.statusCode == 429
                            ? 'Thao tác quá nhanh. Hãy thử lại sau 1 phút.'
                            : 'Server báo lỗi ${res.statusCode}. Kiểm tra dữ liệu và thử lại.'),
            res.statusCode);
      }
      return data;
    } on TimeoutException {
      throw ApiException(
          'Kết nối quá thời gian. Kiểm tra địa chỉ API và mạng.');
    } on http.ClientException {
      throw ApiException(
          'Không kết nối được API. Kiểm tra server, Wi-Fi và địa chỉ trong Cấu hình kết nối.');
    }
  }

  static void logout() {
    token = null;
    user = null;
  }
}
