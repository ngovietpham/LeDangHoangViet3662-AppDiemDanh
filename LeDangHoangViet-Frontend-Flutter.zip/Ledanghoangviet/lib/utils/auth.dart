import '../services/auth_service.dart';

class Auth {
  static Future<Map<String, dynamic>> login(String username, String password,
          {required String otp}) =>
      AuthService().login(username, password, otp: otp);
}
