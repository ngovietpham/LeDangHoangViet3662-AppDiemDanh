import 'dart:math' as math;

class MotionReading {
  double x = 0, y = 0, z = 0, peak = 0;
  int shakes = 0;
  final List<double> samples = [];
  bool _aboveThreshold = false;
  DateTime? _lastShake;

  void add(double nextX, double nextY, double nextZ, DateTime time) {
    if (![nextX, nextY, nextZ].every((v) => v.isFinite)) return;
    x = nextX;
    y = nextY;
    z = nextZ;
    final delta = (math.sqrt(x * x + y * y + z * z) - 9.80665).abs();
    peak = math.max(peak, delta);
    samples.add(delta);
    if (samples.length > 80) samples.removeAt(0);
    // A sustained force counts once. The device must settle before counting again.
    if (delta < 3) _aboveThreshold = false;
    if (delta >= 8 && !_aboveThreshold) {
      _aboveThreshold = true;
      if (_lastShake == null ||
          time.difference(_lastShake!).inMilliseconds >= 700) {
        shakes++;
        _lastShake = time;
      }
    }
  }

  void reset() {
    peak = 0;
    shakes = 0;
    samples.clear();
    _aboveThreshold = false;
    _lastShake = null;
  }
}
