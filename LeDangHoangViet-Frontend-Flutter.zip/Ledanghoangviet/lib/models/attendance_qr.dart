class AttendanceQr {
  final String raw;
  final int sessionId;
  final DateTime expiresAt;
  const AttendanceQr._(this.raw, this.sessionId, this.expiresAt);

  static AttendanceQr? tryParse(String raw) {
    final value = raw.trim();
    if (!RegExp(r'^ATTEND\|[1-9]\d*\|\d{10}\|[A-F0-9]{64}$').hasMatch(value)) {
      return null;
    }
    final parts = value.split('|');
    final id = int.tryParse(parts[1]);
    final expiry = int.tryParse(parts[2]);
    if (id == null || expiry == null) return null;
    return AttendanceQr._(value, id,
        DateTime.fromMillisecondsSinceEpoch(expiry * 1000, isUtc: true));
  }

  String? validateFor(int expectedSession, DateTime now) {
    if (sessionId != expectedSession) {
      return 'Mã thuộc buổi học khác. Hãy chọn đúng QR của buổi này.';
    }
    if (!expiresAt.isAfter(now.toUtc())) {
      return 'Mã QR đã hết hạn. Nhờ giảng viên tạo mã mới.';
    }
    return null;
  }

  int remainingSeconds(DateTime now) =>
      ((expiresAt.difference(now.toUtc()).inMilliseconds / 1000).ceil())
          .clamp(0, 3600);
}
