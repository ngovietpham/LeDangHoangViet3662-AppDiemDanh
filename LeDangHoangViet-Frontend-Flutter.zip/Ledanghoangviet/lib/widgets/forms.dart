import 'package:flutter/material.dart';

void message(BuildContext context, String text) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

class EmptyState extends StatelessWidget {
  final String text;
  const EmptyState(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.all(30),
      child: Column(children: [
        const Icon(Icons.inbox_outlined, size: 42, color: Colors.blueGrey),
        const SizedBox(height: 16),
        Text(text, textAlign: TextAlign.center)
      ]));
}

Future<bool> confirmDelete(BuildContext context, String text) async =>
    await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
                title: const Text('Xác nhận xóa'),
                content: Text(text),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(c, false),
                      child: const Text('Hủy')),
                  FilledButton(
                      onPressed: () => Navigator.pop(c, true),
                      child: const Text('Xóa'))
                ])) ??
    false;

class FieldSpec {
  final String key, label, value;
  final bool secret, number;
  final List<String>? choices;
  final Map<String, String>? labels;
  const FieldSpec(this.key, this.label,
      {this.value = '',
      this.secret = false,
      this.number = false,
      this.choices,
      this.labels});
}

Future<Map<String, dynamic>?> editFields(
    BuildContext context, String title, List<FieldSpec> fields) async {
  final controllers = {
    for (final f in fields) f.key: TextEditingController(text: f.value)
  };
  final form = GlobalKey<FormState>();
  final value = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (c) => AlertDialog(
              title: Text(title),
              content: SizedBox(
                  width: 460,
                  child: Form(
                      key: form,
                      child: SingleChildScrollView(
                          child:
                              Column(mainAxisSize: MainAxisSize.min, children: [
                        for (final f in fields)
                          Padding(
                              padding: const EdgeInsets.only(bottom: 14),
                              child: f.choices != null
                                  ? DropdownButtonFormField<String>(
                                      initialValue: f.choices!.contains(f.value)
                                          ? f.value
                                          : f.choices!.first,
                                      isExpanded: true,
                                      decoration:
                                          InputDecoration(labelText: f.label),
                                      items: [
                                        for (final v in f.choices!)
                                          DropdownMenuItem(
                                              value: v,
                                              child: Text(f.labels?[v] ?? v,
                                                  overflow:
                                                      TextOverflow.ellipsis))
                                      ],
                                      onChanged: (v) =>
                                          controllers[f.key]!.text = v ?? '',
                                      validator: (v) =>
                                          v == null ? 'Chọn ${f.label}' : null)
                                  : TextFormField(
                                      controller: controllers[f.key],
                                      obscureText: f.secret,
                                      keyboardType: f.number
                                          ? const TextInputType
                                              .numberWithOptions(
                                              decimal: true, signed: true)
                                          : TextInputType.text,
                                      decoration:
                                          InputDecoration(labelText: f.label),
                                      validator: (v) {
                                        if (v == null || v.trim().isEmpty) {
                                          return 'Nhập ${f.label}';
                                        }
                                        if (f.number &&
                                            (double.tryParse(v) == null ||
                                                !double.parse(v).isFinite)) {
                                          return 'Nhập số hợp lệ';
                                        }
                                        if (f.key == 'email' &&
                                            !RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
                                                .hasMatch(v)) {
                                          return 'Email không hợp lệ';
                                        }
                                        if (f.key == 'totalSessions' &&
                                            int.tryParse(v) == null) {
                                          return 'Nhập số buổi nguyên';
                                        }
                                        return null;
                                      }))
                      ])))),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(c),
                    child: const Text('Hủy')),
                FilledButton(
                    onPressed: () {
                      if (form.currentState!.validate()) {
                        Navigator.pop(c, {
                          for (final e in controllers.entries)
                            e.key: e.key == 'password'
                                ? e.value.text
                                : e.value.text.trim()
                        });
                      }
                    },
                    child: const Text('Lưu'))
              ]));
  // Dialog routes finish their closing animation before releasing controllers.
  await Future<void>.delayed(const Duration(milliseconds: 300));
  for (final c in controllers.values) {
    c.dispose();
  }
  return value;
}

String localTime(dynamic raw) {
  final d = DateTime.tryParse(raw.toString());
  if (d == null) return raw.toString();
  final t = (d.isUtc ? d : DateTime.parse('${raw}Z')).toLocal();
  String z(int n) => n.toString().padLeft(2, '0');
  return '${z(t.day)}/${z(t.month)} ${z(t.hour)}:${z(t.minute)}';
}

String statusName(String s) => switch (s) {
      'Present' => 'Có mặt',
      'Late' => 'Đi muộn',
      'Excused' => 'Vắng có phép',
      'Absent' => 'Vắng',
      _ => s
    };
