import 'package:flutter/material.dart';
import 'main_screen.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});
  @override
  Widget build(BuildContext context) => const DashboardScreen(role: 'Admin');
}
