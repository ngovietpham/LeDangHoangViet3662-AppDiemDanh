import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models/attendance_qr.dart';
import 'qr_scanner_screen.dart';
import '../utils/api_client.dart';
import '../widgets/forms.dart';

class StudentAttendanceScreen extends StatefulWidget {
  final Map<String, dynamic> session, course;
  const StudentAttendanceScreen(
      {super.key, required this.session, required this.course});
  @override
  State<StudentAttendanceScreen> createState() =>
      _StudentAttendanceScreenState();
}

class _StudentAttendanceScreenState extends State<StudentAttendanceScreen> {
  String? qr, error;
  Position? position;
  bool busy = false, done = false;
  Timer? qrTimer;
  int get qrSeconds =>
      AttendanceQr.tryParse(qr ?? '')?.remainingSeconds(DateTime.now()) ?? 0;
  @override
  void initState() {
    super.initState();
    qrTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && qr != null && !done) setState(() {});
    });
  }

  @override
  void dispose() {
    qrTimer?.cancel();
    super.dispose();
  }

  Future<void> locate() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw ApiException('Hãy bật dịch vụ định vị trên điện thoại.');
      }
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) {
        p = await Geolocator.requestPermission();
      }
      if (p == LocationPermission.denied ||
          p == LocationPermission.deniedForever) {
        throw ApiException(
            'Chưa có quyền vị trí. Vào cài đặt ứng dụng để cho phép vị trí khi sử dụng.');
      }
      final value = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.high,
              timeLimit: Duration(seconds: 20)));
      if (mounted) setState(() => position = value);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> checkin() async {
    if (qr == null || position == null) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final validation = AttendanceQr.tryParse(qr!)
          ?.validateFor(widget.session['id'], DateTime.now());
      if (validation != null) throw ApiException(validation);
      final p = position!;
      if (DateTime.now().difference(p.timestamp) >
          const Duration(seconds: 60)) {
        throw ApiException('Vị trí đã cũ. Hãy lấy vị trí mới trước khi gửi.');
      }
      final data = await ApiClient.request(
          'sessions/${widget.session['id']}/check-in',
          method: 'POST',
          body: {
            'qrToken': qr,
            'latitude': p.latitude,
            'longitude': p.longitude,
            'accuracy': p.accuracy,
            'isMocked': p.isMocked
          });
      if (mounted) {
        setState(() {
          done = true;
          error =
              '${statusName(data['status'])} • Cách lớp ${data['distanceMeters'].round()} m. Đã lưu trên server.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Điểm danh của tôi')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Icon(done ? Icons.check_circle : Icons.qr_code_scanner,
            size: 72, color: const Color(0xff087f8c)),
        const SizedBox(height: 20),
        Text(widget.course['name'],
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(
            'Buổi #${widget.session['id']} • Bán kính ${widget.course['radiusMeters'].round()} m',
            textAlign: TextAlign.center),
        const SizedBox(height: 24),
        if (!done) ...[
          FilledButton.icon(
              onPressed: busy
                  ? null
                  : () async {
                      final value = await Navigator.push<String>(
                          context,
                          MaterialPageRoute(
                              builder: (_) => QrScannerScreen(
                                  sessionId: widget.session['id'])));
                      if (value != null && mounted) {
                        setState(() {
                          qr = value;
                          error = null;
                        });
                      }
                    },
              icon: const Icon(Icons.qr_code_scanner),
              label: Text(qr == null
                  ? '1. Quét QR của giảng viên'
                  : '1. Đã có QR • Quét lại')),
          if (qr != null)
            Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(
                    qrSeconds > 0
                        ? 'QR còn hiệu lực $qrSeconds giây'
                        : 'QR đã hết hạn • hãy quét mã mới',
                    style: TextStyle(
                        color: qrSeconds > 0
                            ? const Color(0xff087f8c)
                            : Colors.red))),
          const SizedBox(height: 16),
          const Text(
              'Vị trí chỉ gửi khi bạn nhấn xác nhận điểm danh, dùng để kiểm tra khoảng cách tới lớp.'),
          const SizedBox(height: 12),
          OutlinedButton.icon(
              onPressed: busy ? null : locate,
              icon: const Icon(Icons.my_location),
              label: Text(position == null
                  ? '2. Lấy vị trí hiện tại'
                  : '2. Cập nhật vị trí')),
          if (position != null)
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(
                    'Vĩ độ ${position!.latitude.toStringAsFixed(6)}\nKinh độ ${position!.longitude.toStringAsFixed(6)}\nĐộ chính xác ±${position!.accuracy.round()} m')),
          const SizedBox(height: 20),
          FilledButton.icon(
              onPressed:
                  busy || qr == null || qrSeconds == 0 || position == null
                      ? null
                      : checkin,
              icon: const Icon(Icons.send_outlined),
              label: const Text('3. Xác nhận & gửi điểm danh')),
        ],
        if (busy)
          const Padding(
              padding: EdgeInsets.all(20),
              child: Center(child: CircularProgressIndicator())),
        if (error != null)
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Text(error!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: done ? const Color(0xff087f8c) : Colors.red,
                      fontWeight: FontWeight.w600))),
        if (done)
          FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Xem lịch sử')),
      ]));
}
