import 'dart:async';
import '../models/motion_reading.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MotionScreen extends StatefulWidget {
  const MotionScreen({super.key});
  @override
  State<MotionScreen> createState() => _MotionScreenState();
}

class _MotionScreenState extends State<MotionScreen>
    with WidgetsBindingObserver {
  StreamSubscription<dynamic>? sub;
  final reading = MotionReading();
  double get x => reading.x;
  double get y => reading.y;
  double get z => reading.z;
  double get peak => reading.peak;
  int get shakes => reading.shakes;
  List<double> get samples => reading.samples;
  String? error;
  bool userPaused = false;
  void start() {
    if (sub != null || userPaused) return;
    sub = const EventChannel('attendance/motion')
        .receiveBroadcastStream()
        .listen((event) {
      if (!mounted) return;
      final a = (event as List).cast<num>();
      setState(() {
        reading.add(
            a[0].toDouble(), a[1].toDouble(), a[2].toDouble(), DateTime.now());
      });
    }, onError: (Object e) {
      if (mounted) {
        sub?.cancel();
        sub = null;
        setState(() => error =
            'Thiết bị không có gia tốc kế hoặc nền tảng chưa hỗ trợ. Hãy thử trên điện thoại Android.');
      }
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    start();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && sub == null) {
      start();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      sub?.cancel();
      sub = null;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Đo chuyển động trực tiếp')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        const Icon(Icons.sensors, size: 70, color: Color(0xff087f8c)),
        const SizedBox(height: 16),
        const Text('Thử nghiêng hoặc lắc nhẹ điện thoại',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Text(userPaused ? 'Đã tạm dừng đo' : 'Đang đo • 10 mẫu/giây',
            textAlign: TextAlign.center),
        const SizedBox(height: 20),
        if (error != null)
          Text(error!, style: const TextStyle(color: Colors.red)),
        Card(
            child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  Text(
                      'X ${x.toStringAsFixed(2)}  •  Y ${y.toStringAsFixed(2)}  •  Z ${z.toStringAsFixed(2)}',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  const Text('Gia tốc theo 3 trục (m/s²)'),
                  const SizedBox(height: 24),
                  SizedBox(
                      height: 150,
                      width: double.infinity,
                      child: CustomPaint(
                          painter: MotionPainter(List.of(samples)))),
                  const SizedBox(height: 20),
                  Text('$shakes',
                      style: const TextStyle(
                          fontSize: 48,
                          fontWeight: FontWeight.w800,
                          color: Color(0xff087f8c))),
                  const Text('lần chuyển động mạnh'),
                  const SizedBox(height: 12),
                  Text('Biến thiên lớn nhất: ${peak.toStringAsFixed(2)} m/s²')
                ]))),
        const SizedBox(height: 16),
        const Text(
            'Dữ liệu lấy từ gia tốc kế Android, cập nhật theo thời gian thực. Biểu đồ thể hiện độ lệch so với trọng lực. Ngưỡng đếm 8 m/s²; trở về dưới 3 m/s² trước lần lắc tiếp theo, cách nhau ít nhất 700 ms. Dữ liệu ở trên thiết bị, không dùng để xác thực danh tính.'),
        const SizedBox(height: 20),
        OutlinedButton.icon(
            onPressed: () => setState(reading.reset),
            icon: const Icon(Icons.restart_alt),
            label: const Text('Đo lại')),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () async {
            if (userPaused || error != null) {
              setState(() {
                userPaused = false;
                error = null;
              });
              start();
            } else {
              setState(() => userPaused = true);
              final active = sub;
              sub = null;
              await active?.cancel();
            }
          },
          icon: Icon(
              userPaused || error != null ? Icons.play_arrow : Icons.pause),
          label:
              Text(userPaused || error != null ? 'Tiếp tục đo' : 'Tạm dừng đo'),
        ),
      ]));
}

class MotionPainter extends CustomPainter {
  final List<double> values;
  MotionPainter(this.values);
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = const Color(0xffe1ebef)
      ..strokeWidth = 1;
    for (var i = 0; i < 5; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    if (values.length < 2) return;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final p = Offset(i * size.width / 79,
          size.height - (values[i] / 25).clamp(0, 1) * size.height);
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    canvas.drawPath(
        path,
        Paint()
          ..color = const Color(0xff087f8c)
          ..strokeWidth = 3
          ..style = PaintingStyle.stroke);
  }

  @override
  bool shouldRepaint(covariant MotionPainter old) => true;
}
