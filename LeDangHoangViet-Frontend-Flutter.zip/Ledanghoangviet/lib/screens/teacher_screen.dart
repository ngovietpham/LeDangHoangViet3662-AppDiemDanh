import 'package:flutter/material.dart';
import 'main_screen.dart';

class TeacherScreen extends StatelessWidget {
  const TeacherScreen({super.key});
  @override
  Widget build(BuildContext context) => const DashboardScreen(role: 'Teacher');
}
