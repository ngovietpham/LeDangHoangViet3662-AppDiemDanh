import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../utils/api_client.dart';
import '../config/config_url.dart';
import 'registration_screen.dart';
import 'admin_screen.dart';
import 'teacher_screen.dart';
import 'main_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final form = GlobalKey<FormState>();
  final username = TextEditingController(),
      password = TextEditingController(),
      otp = TextEditingController();
  bool busy = false, sent = false, hide = true;
  String? error, notice;
  @override
  void dispose() {
    username.dispose();
    password.dispose();
    otp.dispose();
    super.dispose();
  }

  Future<void> act(bool login) async {
    if (!form.currentState!.validate()) return;
    setState(() {
      busy = true;
      error = null;
      notice = null;
    });
    try {
      if (login) {
        final data = await AuthService()
            .login(username.text.trim(), password.text, otp: otp.text.trim());
        if (!mounted) return;
        final Widget page = switch (data['role']) {
          'Admin' => const AdminScreen(),
          'Teacher' => const TeacherScreen(),
          _ => const MainScreen()
        };
        Navigator.pushAndRemoveUntil(
            context, MaterialPageRoute(builder: (_) => page), (_) => false);
      } else {
        final data = await ApiClient.request('Authenticate/request-login-otp',
            method: 'POST',
            body: {
              'username': username.text.trim(),
              'password': password.text
            });
        if (mounted) {
          setState(() {
            sent = true;
            notice = data['devOtp'] != null
                ? 'DEMO — mã OTP: ${data['devOtp']} (không gửi email)'
                : data['message'];
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> server() async {
    final c = TextEditingController(text: ConfigUrl.baseUrl);
    final value = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
                title: const Text('Cấu hình kết nối'),
                content: TextField(
                    controller: c,
                    decoration: const InputDecoration(
                        labelText: 'Địa chỉ API',
                        helperText:
                            'Emulator: http://10.0.2.2:5300/api/\nĐiện thoại: http://IP-LAPTOP:5300/api/',
                        helperMaxLines: 3)),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Hủy')),
                  FilledButton(
                      onPressed: () {
                        final u = Uri.tryParse(c.text.trim());
                        if (u != null &&
                            ['http', 'https'].contains(u.scheme) &&
                            u.host.isNotEmpty) {
                          Navigator.pop(ctx, c.text.trim());
                        }
                      },
                      child: const Text('Lưu'))
                ]));
    if (value != null && mounted) {
      setState(() {
        ConfigUrl.overrideUrl = value;
        notice = 'Đã đổi địa chỉ API cho lần chạy này.';
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      body: SafeArea(
          child: Center(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 440),
                      child: Form(
                          key: form,
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                const Icon(Icons.fact_check_rounded,
                                    size: 62, color: Color(0xff087f8c)),
                                const SizedBox(height: 16),
                                const Text('Attend',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 36,
                                        fontWeight: FontWeight.w800,
                                        color: Color(0xff143747))),
                                const Text(
                                    'Có mặt hôm nay. Vững bước ngày mai.',
                                    textAlign: TextAlign.center),
                                const SizedBox(height: 32),
                                TextFormField(
                                    controller: username,
                                    enabled: !busy,
                                    decoration: const InputDecoration(
                                        labelText: 'Tên đăng nhập',
                                        prefixIcon: Icon(Icons.person_outline)),
                                    validator: (v) => v!.trim().isEmpty
                                        ? 'Nhập tên đăng nhập'
                                        : null),
                                const SizedBox(height: 14),
                                TextFormField(
                                    controller: password,
                                    enabled: !busy,
                                    obscureText: hide,
                                    decoration: InputDecoration(
                                        labelText: 'Mật khẩu',
                                        prefixIcon:
                                            const Icon(Icons.lock_outline),
                                        suffixIcon: IconButton(
                                            onPressed: () =>
                                                setState(() => hide = !hide),
                                            icon: Icon(hide
                                                ? Icons.visibility_outlined
                                                : Icons
                                                    .visibility_off_outlined))),
                                    validator: (v) =>
                                        v!.isEmpty ? 'Nhập mật khẩu' : null),
                                if (sent) ...[
                                  const SizedBox(height: 14),
                                  TextFormField(
                                      controller: otp,
                                      keyboardType: TextInputType.number,
                                      maxLength: 6,
                                      decoration: const InputDecoration(
                                          labelText: 'OTP 6 chữ số từ email',
                                          prefixIcon: Icon(
                                              Icons.mark_email_read_outlined)),
                                      validator: (v) =>
                                          RegExp(r'^\d{6}$').hasMatch(v ?? '')
                                              ? null
                                              : 'Nhập đủ 6 chữ số')
                                ],
                                if (notice != null)
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 12),
                                      child: Text(notice!,
                                          style: const TextStyle(
                                              color: Color(0xff087f8c)))),
                                if (error != null)
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 12),
                                      child: Text(error!,
                                          style: const TextStyle(
                                              color: Colors.red))),
                                const SizedBox(height: 20),
                                FilledButton.icon(
                                    onPressed: busy ? null : () => act(sent),
                                    icon: busy
                                        ? const SizedBox(
                                            width: 18,
                                            height: 18,
                                            child: CircularProgressIndicator(
                                                strokeWidth: 2))
                                        : Icon(sent
                                            ? Icons.login
                                            : Icons.email_outlined),
                                    label: Text(busy
                                        ? 'Đang xử lý…'
                                        : sent
                                            ? 'Xác thực & đăng nhập'
                                            : 'Gửi OTP đăng nhập')),
                                if (sent)
                                  TextButton(
                                      onPressed: busy
                                          ? null
                                          : () {
                                              setState(() {
                                                sent = false;
                                                otp.clear();
                                              });
                                            },
                                      child: const Text(
                                          'Đổi tài khoản / Gửi lại OTP')),
                                TextButton(
                                    onPressed: busy
                                        ? null
                                        : () => Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (_) =>
                                                    const RegistrationScreen())),
                                    child: const Text(
                                        'Chưa có tài khoản? Đăng ký sinh viên')),
                                const SizedBox(height: 12),
                                TextButton.icon(
                                    onPressed: busy ? null : server,
                                    icon: const Icon(Icons.dns_outlined,
                                        size: 18),
                                    label: const Text('Cấu hình kết nối')),
                              ])))))));
}
