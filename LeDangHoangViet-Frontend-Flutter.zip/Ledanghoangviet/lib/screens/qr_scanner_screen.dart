import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../models/attendance_qr.dart';

class QrScannerScreen extends StatefulWidget {
  final int sessionId;
  const QrScannerScreen({super.key, required this.sessionId});
  @override
  State<QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends State<QrScannerScreen>
    with WidgetsBindingObserver {
  final controller = MobileScannerController(
      autoStart: false, formats: [BarcodeFormat.qrCode]);
  bool returned = false, picking = false, starting = false;
  String? error, lastInvalid;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => startCamera());
  }

  Future<void> startCamera() async {
    if (!mounted ||
        returned ||
        picking ||
        starting ||
        controller.value.isRunning) {
      return;
    }
    starting = true;
    try {
      await controller.start();
    } catch (_) {
      if (mounted) {
        setState(() =>
            error = 'Chưa mở được camera. Bạn có thể chọn ảnh QR bên dưới.');
      }
    } finally {
      starting = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!controller.value.hasCameraPermission || picking || returned) return;
    if (state == AppLifecycleState.resumed) {
      unawaited(startCamera());
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      unawaited(controller.stop());
    }
  }

  bool accept(String value) {
    if (returned || !mounted) return false;
    final qr = AttendanceQr.tryParse(value);
    final reason = qr == null
        ? 'Đây không phải mã QR điểm danh của ứng dụng.'
        : qr.validateFor(widget.sessionId, DateTime.now());
    if (reason != null) {
      if (lastInvalid != value) {
        lastInvalid = value;
        setState(() => error = reason);
      }
      return false;
    }
    returned = true;
    unawaited(controller.stop());
    Navigator.pop(context, qr!.raw);
    return true;
  }

  void onDetect(BarcodeCapture capture) {
    if (returned || picking) return;
    for (final barcode in capture.barcodes) {
      final value = barcode.rawValue;
      if (value != null && accept(value)) break;
    }
  }

  Future<void> pickImage() async {
    if (picking || returned) return;
    setState(() {
      picking = true;
      error = null;
      lastInvalid = null;
    });
    try {
      if (controller.value.isRunning) await controller.stop();
      final path = await const MethodChannel('attendance/device')
          .invokeMethod<String>('pickQrImage');
      if (path == null || !mounted) return;
      final capture =
          await controller.analyzeImage(path, formats: [BarcodeFormat.qrCode]);
      if (!mounted || returned) return;
      final values = capture?.barcodes
              .map((b) => b.rawValue)
              .whereType<String>()
              .toList() ??
          <String>[];
      if (values.isEmpty) {
        setState(() => error =
            'Không đọc được QR trong ảnh. Chọn ảnh rõ nét, đủ bốn góc của mã.');
      } else {
        for (final value in values) {
          if (accept(value)) break;
        }
      }
    } catch (_) {
      if (mounted) {
        setState(() => error =
            'Không đọc được ảnh. Hãy thử ảnh khác hoặc quét bằng camera.');
      }
    } finally {
      if (mounted && !returned) {
        setState(() => picking = false);
        unawaited(startCamera());
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Quét QR điểm danh')),
        body: Column(children: [
          Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                  'Buổi #${widget.sessionId} • Quét mã đang hiển thị trên màn hình giảng viên.')),
          Expanded(
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: MobileScanner(
                    controller: controller,
                    useAppLifecycleState: false,
                    onDetect: onDetect,
                    errorBuilder: (context, scanError) => const Center(
                        child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                                'Camera chưa sẵn sàng. Kiểm tra quyền camera hoặc chọn ảnh QR.',
                                textAlign: TextAlign.center))),
                  ))),
          if (error != null)
            Padding(
                padding: const EdgeInsets.all(16),
                child: Text(error!,
                    style: const TextStyle(color: Colors.red),
                    textAlign: TextAlign.center)),
          Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: picking ? null : pickImage,
                    icon: const Icon(Icons.photo_library_outlined),
                    label: Text(
                        picking ? 'Đang đọc ảnh…' : 'Chọn ảnh QR từ thiết bị'),
                  ))),
          const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 24),
              child: Text(
                  'Ảnh và camera đều dùng cùng kiểm tra mã hết hạn, buổi học và GPS trên server.',
                  textAlign: TextAlign.center)),
        ]),
      );
}
