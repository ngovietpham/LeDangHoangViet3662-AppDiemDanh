import 'package:flutter/material.dart';
import '../utils/api_client.dart';
import 'login_screen.dart';
import 'course_screen.dart';
import 'motion_screen.dart';
import '../widgets/forms.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});
  @override
  Widget build(BuildContext context) => const DashboardScreen(role: 'Student');
}

class DashboardScreen extends StatefulWidget {
  final String role;
  const DashboardScreen({super.key, required this.role});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<dynamic> courses = [], users = [];
  bool busy = true;
  String? error;
  int tab = 0;
  bool get admin => widget.role == 'Admin';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (mounted) {
      setState(() {
        busy = true;
        error = null;
      });
    }
    try {
      final c = await ApiClient.request('courses');
      final u = admin ? await ApiClient.request('Users') : [];
      if (mounted) {
        setState(() {
          courses = c;
          users = u;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> signout() async {
    ApiClient.logout();
    if (mounted) {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
    }
  }

  Future<void> editUser([Map<String, dynamic>? u]) async {
    final data = await editFields(
        context, u == null ? 'Thêm tài khoản' : 'Sửa tài khoản', [
      FieldSpec('username', 'Tên đăng nhập', value: u?['username'] ?? ''),
      FieldSpec('email', 'Email', value: u?['email'] ?? ''),
      FieldSpec('initials', 'Họ tên / MSSV', value: u?['initials'] ?? ''),
      if (u == null)
        const FieldSpec('password', 'Mật khẩu ban đầu', secret: true),
      FieldSpec('role', 'Vai trò',
          value: u?['role'] ?? 'Student',
          choices: const ['Student', 'Teacher', 'Admin']),
    ]);
    if (data == null) return;
    await run(() => ApiClient.request(u == null ? 'Users' : 'Users/${u['id']}',
        method: u == null ? 'POST' : 'PUT', body: data));
  }

  Future<void> editCourse([Map<String, dynamic>? c]) async {
    final teachers = users.where((u) => u['role'] == 'Teacher').toList();
    if (teachers.isEmpty) {
      message(context, 'Thêm tài khoản Giảng viên trước khi tạo lớp.');
      return;
    }
    final fields = [
      FieldSpec('code', 'Mã lớp', value: c?['code'] ?? ''),
      FieldSpec('name', 'Tên học phần', value: c?['name'] ?? ''),
      FieldSpec('room', 'Phòng học', value: c?['room'] ?? ''),
      FieldSpec('teacherId', 'Giảng viên',
          value: c?['teacherId'] ?? teachers.first['id'],
          choices: teachers.map<String>((u) => u['id']).toList(),
          labels: {
            for (final u in teachers)
              u['id']: '${u['initials']} (${u['username']})'
          }),
      FieldSpec('totalSessions', 'Tổng số buổi',
          value: '${c?['totalSessions'] ?? 15}', number: true),
      FieldSpec('minimumRate', 'Tỷ lệ tối thiểu (0.1–1)',
          value: '${c?['minimumRate'] ?? 0.8}', number: true),
      FieldSpec('latitude', 'Vĩ độ lớp',
          value: '${c?['latitude'] ?? 10.762622}', number: true),
      FieldSpec('longitude', 'Kinh độ lớp',
          value: '${c?['longitude'] ?? 106.660172}', number: true),
      FieldSpec('radiusMeters', 'Bán kính điểm danh (m)',
          value: '${c?['radiusMeters'] ?? 150}', number: true)
    ];
    final data = await editFields(
        context, c == null ? 'Thêm lớp học phần' : 'Sửa lớp học phần', fields);
    if (data == null) return;
    await run(() => ApiClient.request(
            c == null ? 'courses' : 'courses/${c['id']}',
            method: c == null ? 'POST' : 'PUT',
            body: {
              ...data,
              'totalSessions': int.parse(data['totalSessions']),
              for (final k in [
                'minimumRate',
                'latitude',
                'longitude',
                'radiusMeters'
              ])
                k: double.parse(data[k])
            }));
  }

  Future<void> run(Future<dynamic> Function() action) async {
    try {
      await action();
      if (mounted) {
        message(context, 'Đã lưu thay đổi.');
        await load();
      }
    } catch (e) {
      if (mounted) message(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final role = admin
        ? 'Quản trị viên'
        : widget.role == 'Teacher'
            ? 'Giảng viên'
            : 'Sinh viên';
    final person =
        ApiClient.user?['initials'] ?? ApiClient.user?['username'] ?? role;
    return Scaffold(
        appBar: AppBar(
            title: const Text('Attend',
                style: TextStyle(fontWeight: FontWeight.w800)),
            actions: [
              IconButton(
                  onPressed: load,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Tải lại'),
              IconButton(
                  onPressed: signout,
                  icon: const Icon(Icons.logout),
                  tooltip: 'Đăng xuất')
            ]),
        body: busy
            ? const Center(child: CircularProgressIndicator())
            : error != null
                ? Center(
                    child: Padding(
                        padding: const EdgeInsets.all(24),
                        child:
                            Column(mainAxisSize: MainAxisSize.min, children: [
                          Text(error!, textAlign: TextAlign.center),
                          const SizedBox(height: 16),
                          FilledButton(
                              onPressed:
                                  ApiClient.token == null ? signout : load,
                              child: Text(ApiClient.token == null
                                  ? 'Về đăng nhập'
                                  : 'Thử lại'))
                        ])))
                : RefreshIndicator(
                    onRefresh: load,
                    child:
                        ListView(padding: const EdgeInsets.all(20), children: [
                      Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                              gradient: const LinearGradient(colors: [
                                Color(0xff123a4a),
                                Color(0xff087f8c)
                              ]),
                              borderRadius: BorderRadius.circular(24)),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(role.toUpperCase(),
                                    style: const TextStyle(
                                        color: Color(0xff9ee9df),
                                        fontSize: 12,
                                        letterSpacing: 2)),
                                const SizedBox(height: 10),
                                Text('Xin chào, $person',
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 23,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(height: 12),
                                Text(
                                    admin
                                        ? '${users.length} tài khoản • ${courses.length} lớp học phần'
                                        : '${courses.length} lớp học phần của bạn',
                                    style:
                                        const TextStyle(color: Colors.white70))
                              ])),
                      const SizedBox(height: 24),
                      if (tab == 0) ...[
                        const Text('Lớp học phần',
                            style: TextStyle(
                                fontSize: 21, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        if (courses.isEmpty)
                          const EmptyState(
                              'Chưa có lớp học phần.\nGiảng viên hoặc Admin thêm sinh viên vào lớp bằng tên đăng nhập.'),
                        for (final c in courses)
                          Card(
                              child: Padding(
                                  padding: const EdgeInsets.all(8),
                                  child: ListTile(
                                      contentPadding: const EdgeInsets.all(12),
                                      leading: CircleAvatar(
                                          backgroundColor:
                                              const Color(0xffe0f3f1),
                                          child: Text(c['code']
                                              .toString()
                                              .substring(
                                                  0,
                                                  c['code']
                                                      .toString()
                                                      .length
                                                      .clamp(0, 2)))),
                                      title: Text(c['name'],
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w700)),
                                      subtitle: Text(
                                          '${c['code']} • ${c['room']}\n${c['totalSessions']} buổi • yêu cầu ${(c['minimumRate'] * 100).round()}%'),
                                      isThreeLine: true,
                                      onTap: () async {
                                        await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (_) => CourseScreen(
                                                    course: Map<String,
                                                        dynamic>.from(c),
                                                    role: widget.role)));
                                        load();
                                      },
                                      trailing: admin
                                          ? PopupMenuButton<String>(
                                              onSelected: (v) async {
                                                if (v == 'edit') {
                                                  editCourse(
                                                      Map<String, dynamic>.from(
                                                          c));
                                                } else if (await confirmDelete(
                                                    context,
                                                    'Xóa lớp và toàn bộ buổi học, điểm danh liên quan?')) {
                                                  await run(() =>
                                                      ApiClient.request(
                                                          'courses/${c['id']}',
                                                          method: 'DELETE'));
                                                }
                                              },
                                              itemBuilder: (_) => const [
                                                    PopupMenuItem(
                                                        value: 'edit',
                                                        child: Text('Sửa lớp')),
                                                    PopupMenuItem(
                                                        value: 'delete',
                                                        child: Text('Xóa lớp'))
                                                  ])
                                          : const Icon(Icons.chevron_right)))),
                      ] else if (admin && tab == 1) ...[
                        const Text('Quản lý tài khoản',
                            style: TextStyle(
                                fontSize: 21, fontWeight: FontWeight.bold)),
                        for (final u in users)
                          Card(
                              child: ListTile(
                                  leading: const CircleAvatar(
                                      child: Icon(Icons.person_outline)),
                                  title: Text(u['initials'] ?? u['username']),
                                  subtitle: Text(
                                      '${u['username']} • ${u['role']}\n${u['email']}'),
                                  isThreeLine: true,
                                  trailing: PopupMenuButton<String>(
                                      onSelected: (v) async {
                                        if (v == 'edit') {
                                          editUser(
                                              Map<String, dynamic>.from(u));
                                        } else if (await confirmDelete(context,
                                            'Xóa tài khoản ${u['username']}?')) {
                                          await run(() => ApiClient.request(
                                              'Users/${u['id']}',
                                              method: 'DELETE'));
                                        }
                                      },
                                      itemBuilder: (_) => const [
                                            PopupMenuItem(
                                                value: 'edit',
                                                child: Text('Sửa')),
                                            PopupMenuItem(
                                                value: 'delete',
                                                child: Text('Xóa'))
                                          ]))),
                      ] else ...[
                        const Text('Công cụ',
                            style: TextStyle(
                                fontSize: 21, fontWeight: FontWeight.bold)),
                        Card(
                            child: ListTile(
                          leading: const Icon(Icons.sensors, size: 32),
                          title: const Text('Đo chuyển động'),
                          subtitle: const Text(
                              'Gia tốc kế trực tiếp • biểu đồ và đếm lần lắc'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const MotionScreen())),
                        )),
                      ],
                      const SizedBox(height: 80),
                    ])),
        floatingActionButton: admin && tab < 2
            ? FloatingActionButton.extended(
                onPressed: () => tab == 0 ? editCourse() : editUser(),
                icon: const Icon(Icons.add),
                label: Text(tab == 0 ? 'Thêm lớp' : 'Thêm tài khoản'))
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: [
            const NavigationDestination(
                icon: Icon(Icons.school_outlined),
                selectedIcon: Icon(Icons.school),
                label: 'Lớp học'),
            if (admin)
              const NavigationDestination(
                  icon: Icon(Icons.people_outline),
                  selectedIcon: Icon(Icons.people),
                  label: 'Tài khoản'),
            const NavigationDestination(
                icon: Icon(Icons.sensors), label: 'Công cụ'),
          ],
        ));
  }
}
