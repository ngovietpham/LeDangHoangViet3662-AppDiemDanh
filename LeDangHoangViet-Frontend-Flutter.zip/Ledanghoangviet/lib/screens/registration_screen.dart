import 'package:flutter/material.dart';
import '../utils/api_client.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});
  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final form = GlobalKey<FormState>();
  final name = TextEditingController(),
      email = TextEditingController(),
      initials = TextEditingController(),
      password = TextEditingController(),
      otp = TextEditingController();
  bool sent = false, busy = false;
  String? error, notice;
  @override
  void dispose() {
    for (final c in [name, email, initials, password, otp]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> submit() async {
    if (!form.currentState!.validate()) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final data = await ApiClient.request(
          sent ? 'Authenticate/register-with-otp' : 'Authenticate/send-otp',
          method: 'POST',
          body: sent
              ? {
                  'username': name.text.trim(),
                  'email': email.text.trim(),
                  'initials': initials.text.trim(),
                  'password': password.text,
                  'role': 'Student',
                  'otp': otp.text.trim()
                }
              : {'email': email.text.trim()});
      if (!mounted) return;
      if (sent) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Đăng ký thành công. Hãy đăng nhập.')));
        Navigator.pop(context);
      } else {
        setState(() {
          sent = true;
          notice = data['devOtp'] != null
              ? 'DEMO — mã OTP: ${data['devOtp']} (không gửi email)'
              : data['message'];
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Đăng ký sinh viên')),
      body: Center(
          child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: Form(
                  key: form,
                  child: ListView(padding: const EdgeInsets.all(24), children: [
                    const Text('Bắt đầu hành trình của bạn',
                        style: TextStyle(
                            fontSize: 25, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text(
                        'Xác thực email để tạo tài khoản. Giảng viên được quản trị viên cấp quyền.'),
                    const SizedBox(height: 24),
                    field(name, 'Tên đăng nhập'),
                    field(initials, 'Họ tên / MSSV'),
                    field(email, 'Email', emailField: true),
                    field(password, 'Mật khẩu', secret: true),
                    if (sent) field(otp, 'OTP 6 chữ số'),
                    if (notice != null)
                      Text(notice!,
                          style: const TextStyle(color: Color(0xff087f8c))),
                    if (error != null)
                      Text(error!, style: const TextStyle(color: Colors.red)),
                    const SizedBox(height: 20),
                    FilledButton(
                        onPressed: busy ? null : submit,
                        child: Text(busy
                            ? 'Đang xử lý…'
                            : sent
                                ? 'Xác nhận OTP & tạo tài khoản'
                                : 'Gửi OTP qua email')),
                    if (sent)
                      TextButton(
                          onPressed: busy
                              ? null
                              : () => setState(() {
                                    sent = false;
                                    otp.clear();
                                    notice = null;
                                  }),
                          child: const Text('Đổi thông tin / Gửi lại OTP')),
                  ])))));
  Widget field(TextEditingController c, String label,
          {bool secret = false, bool emailField = false}) =>
      Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: TextFormField(
              controller: c,
              enabled: !busy && !sent || c == otp && !busy,
              obscureText: secret,
              keyboardType: emailField
                  ? TextInputType.emailAddress
                  : c == otp
                      ? TextInputType.number
                      : TextInputType.text,
              decoration: InputDecoration(
                  labelText: label,
                  helperText: secret
                      ? 'Ít nhất 8 ký tự, có chữ hoa, chữ thường, số và ký tự đặc biệt'
                      : null,
                  helperMaxLines: 2),
              validator: (v) {
                if (v == null || v.trim().isEmpty) {
                  return 'Vui lòng nhập $label';
                }
                if (emailField &&
                    !RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(v)) {
                  return 'Email không hợp lệ';
                }
                if (secret &&
                    (v.length < 8 ||
                        !RegExp(r'[A-Z]').hasMatch(v) ||
                        !RegExp(r'[a-z]').hasMatch(v) ||
                        !RegExp(r'[0-9]').hasMatch(v) ||
                        !RegExp(r'[^a-zA-Z0-9]').hasMatch(v))) {
                  return 'Mật khẩu chưa đủ độ mạnh';
                }
                if (c == otp && !RegExp(r'^\d{6}$').hasMatch(v)) {
                  return 'Nhập đủ 6 chữ số';
                }
                return null;
              }));
}
