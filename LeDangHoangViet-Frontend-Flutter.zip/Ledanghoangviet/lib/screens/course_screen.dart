import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../utils/api_client.dart';
import '../widgets/forms.dart';
import 'student_attendance_screen.dart';

class CourseScreen extends StatefulWidget {
  final Map<String, dynamic> course;
  final String role;
  const CourseScreen({super.key, required this.course, required this.role});
  @override
  State<CourseScreen> createState() => _CourseScreenState();
}

class _CourseScreenState extends State<CourseScreen> {
  List<dynamic> sessions = [], students = [], records = [];
  bool busy = true;
  String? error;
  int tab = 0;
  bool get staff => widget.role != 'Student';
  int get cid => widget.course['id'];
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await Future.wait([
        ApiClient.request('courses/$cid/sessions'),
        ApiClient.request('courses/$cid/attendance'),
        if (staff) ApiClient.request('courses/$cid/students')
      ]);
      if (mounted) {
        setState(() {
          sessions = result[0];
          records = result[1];
          if (staff) {
            students = result[2];
          }
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> run(Future<dynamic> Function() action) async {
    try {
      await action();
      if (mounted) {
        message(context, 'Đã lưu thay đổi.');
        await load();
      }
    } catch (e) {
      if (mounted) message(context, e.toString());
    }
  }

  Future<void> editSession([Map<String, dynamic>? session]) async {
    String input(dynamic d) => d == null
        ? DateTime.now().toString().substring(0, 16)
        : DateTime.parse(d.toString().endsWith('Z') ? d : '${d}Z')
            .toLocal()
            .toString()
            .substring(0, 16);
    final data = await editFields(
        context, session == null ? 'Thêm buổi học' : 'Sửa buổi học', [
      FieldSpec('startsAt', 'Bắt đầu (YYYY-MM-DD HH:MM)',
          value: input(session?['startsAt'])),
      FieldSpec('endsAt', 'Kết thúc (YYYY-MM-DD HH:MM)',
          value: session == null
              ? DateTime.now()
                  .add(const Duration(hours: 2))
                  .toString()
                  .substring(0, 16)
              : input(session['endsAt'])),
      FieldSpec('lateAfterMinutes', 'Đi muộn sau (phút)',
          value: '${session?['lateAfterMinutes'] ?? 15}', number: true),
      FieldSpec('isClosed', 'Trạng thái',
          value: session?['isClosed'] == true ? 'Đóng' : 'Mở',
          choices: const ['Mở', 'Đóng'])
    ]);
    if (data == null) return;
    final start = DateTime.tryParse(data['startsAt']),
        end = DateTime.tryParse(data['endsAt']);
    final late = int.tryParse(data['lateAfterMinutes']);
    if (start == null || end == null || late == null) {
      if (mounted) message(context, 'Sai định dạng thời gian hoặc số phút.');
      return;
    }
    await run(() => ApiClient.request(
            session == null ? 'sessions' : 'sessions/${session['id']}',
            method: session == null ? 'POST' : 'PUT',
            body: {
              'courseId': cid,
              'startsAt': start.toUtc().toIso8601String(),
              'endsAt': end.toUtc().toIso8601String(),
              'lateAfterMinutes': late,
              'isClosed': data['isClosed'] == 'Đóng'
            }));
  }

  Future<void> enroll() async {
    final data = await editFields(context, 'Thêm sinh viên vào lớp',
        [const FieldSpec('username', 'Tên đăng nhập sinh viên')]);
    if (data == null) return;
    await run(() =>
        ApiClient.request('courses/$cid/students', method: 'POST', body: data));
  }

  Future<void> manual([Map<String, dynamic>? record]) async {
    if (sessions.isEmpty || students.isEmpty) {
      message(context, 'Cần có buổi học và sinh viên trong lớp trước.');
      return;
    }
    final data = await editFields(context,
        record == null ? 'Điểm danh bổ sung' : 'Điều chỉnh điểm danh', [
      if (record == null) ...[
        FieldSpec('sessionId', 'Buổi học',
            value: '${sessions.first['id']}',
            choices: sessions.map<String>((s) => '${s['id']}').toList(),
            labels: {
              for (final s in sessions) '${s['id']}': localTime(s['startsAt'])
            }),
        FieldSpec('studentId', 'Sinh viên',
            value: students.first['id'],
            choices: students.map<String>((s) => s['id']).toList(),
            labels: {
              for (final s in students)
                s['id']: '${s['initials']} (${s['username']})'
            })
      ],
      FieldSpec('status', 'Trạng thái',
          value: record?['status'] ?? 'Present',
          choices: const [
            'Present',
            'Late',
            'Excused',
            'Absent'
          ],
          labels: const {
            'Present': 'Có mặt',
            'Late': 'Đi muộn',
            'Excused': 'Vắng có phép',
            'Absent': 'Vắng'
          }),
      FieldSpec('note', 'Lý do điều chỉnh', value: record?['note'] ?? '')
    ]);
    if (data == null) return;
    await run(() => ApiClient.request(
            record == null ? 'attendance' : 'attendance/${record['id']}',
            method: record == null ? 'POST' : 'PUT',
            body: {
              ...data,
              'sessionId': record?['sessionId'] ?? int.parse(data['sessionId']),
              'studentId': record?['studentId'] ?? data['studentId']
            }));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: Text(widget.course['code']), actions: [
        IconButton(onPressed: load, icon: const Icon(Icons.refresh))
      ]),
      body: busy
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(
                  child: Padding(
                      padding: const EdgeInsets.all(24), child: Text(error!)))
              : RefreshIndicator(
                  onRefresh: load,
                  child: ListView(padding: const EdgeInsets.all(20), children: [
                    Text(widget.course['name'],
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 26)),
                    const SizedBox(height: 8),
                    Text(
                        '${widget.course['room']} • Bán kính ${widget.course['radiusMeters'].round()} m'),
                    const SizedBox(height: 20),
                    SegmentedButton<int>(
                        segments: [
                          const ButtonSegment(
                              value: 0, label: Text('Buổi học')),
                          const ButtonSegment(value: 1, label: Text('Lịch sử')),
                          if (staff)
                            const ButtonSegment(
                                value: 2, label: Text('Sinh viên'))
                        ],
                        selected: {
                          tab
                        },
                        onSelectionChanged: (s) =>
                            setState(() => tab = s.first)),
                    const SizedBox(height: 20),
                    if (tab == 0) ...[
                      if (sessions.isEmpty)
                        const EmptyState(
                            'Chưa có buổi học. Giảng viên tạo buổi mới để bắt đầu.'),
                      for (final s in sessions)
                        Card(
                            child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(children: [
                                        Expanded(
                                            child: Text(
                                                'Buổi #${s['id']} • ${localTime(s['startsAt'])}',
                                                style: const TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold))),
                                        if (staff)
                                          PopupMenuButton<String>(
                                              onSelected: (v) async {
                                                if (v == 'edit') {
                                                  editSession(
                                                      Map<String, dynamic>.from(
                                                          s));
                                                } else if (await confirmDelete(
                                                    context,
                                                    'Xóa buổi học và các bản ghi điểm danh của buổi này?')) {
                                                  await run(() =>
                                                      ApiClient.request(
                                                          'sessions/${s['id']}',
                                                          method: 'DELETE'));
                                                }
                                              },
                                              itemBuilder: (_) => const [
                                                    PopupMenuItem(
                                                        value: 'edit',
                                                        child: Text(
                                                            'Sửa / đóng buổi')),
                                                    PopupMenuItem(
                                                        value: 'delete',
                                                        child: Text('Xóa'))
                                                  ])
                                      ]),
                                      Text(
                                          'Đến ${localTime(s['endsAt'])} • ${s['isClosed'] ? 'Đã đóng' : 'Mở theo lịch'}'),
                                      const SizedBox(height: 12),
                                      FilledButton.icon(
                                          onPressed: s['isClosed'] == true
                                              ? null
                                              : () async {
                                                  await Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (_) => staff
                                                              ? SessionQrScreen(
                                                                  session: Map<
                                                                          String,
                                                                          dynamic>.from(
                                                                      s),
                                                                  course: widget
                                                                      .course)
                                                              : StudentAttendanceScreen(
                                                                  session: Map<
                                                                          String,
                                                                          dynamic>.from(
                                                                      s),
                                                                  course: widget
                                                                      .course)));
                                                  if (mounted) load();
                                                },
                                          icon: Icon(staff
                                              ? Icons.qr_code
                                              : Icons.qr_code_scanner),
                                          label: Text(staff
                                              ? 'Hiển thị QR điểm danh'
                                              : 'Quét QR & xác thực vị trí'))
                                    ]))),
                    ] else if (tab == 1) ...[
                      if (records.isEmpty)
                        const EmptyState('Chưa có bản ghi điểm danh.'),
                      for (final r in records)
                        Card(
                            child: ListTile(
                                leading: Icon(
                                    r['status'] == 'Absent'
                                        ? Icons.cancel_outlined
                                        : Icons.check_circle_outline,
                                    color: r['status'] == 'Absent'
                                        ? Colors.red
                                        : const Color(0xff087f8c)),
                                title: Text(
                                    '${statusName(r['status'])} • ${r['initials'] ?? r['username']}'),
                                subtitle: Text(
                                    'Buổi #${r['sessionId']} • ${localTime(r['checkedAt'])}${r['distanceMeters'] != null ? ' • ${r['distanceMeters'].round()} m' : ''}\n${r['note'] ?? ''}'),
                                isThreeLine: true,
                                trailing: staff
                                    ? PopupMenuButton<String>(
                                        onSelected: (v) async {
                                          if (v == 'edit') {
                                            manual(
                                                Map<String, dynamic>.from(r));
                                          } else if (await confirmDelete(
                                              context,
                                              'Xóa bản ghi điểm danh này?')) {
                                            await run(() => ApiClient.request(
                                                'attendance/${r['id']}',
                                                method: 'DELETE'));
                                          }
                                        },
                                        itemBuilder: (_) => const [
                                              PopupMenuItem(
                                                  value: 'edit',
                                                  child: Text('Điều chỉnh')),
                                              PopupMenuItem(
                                                  value: 'delete',
                                                  child: Text('Xóa'))
                                            ])
                                    : null)),
                    ] else if (staff) ...[
                      if (students.isEmpty)
                        const EmptyState(
                            'Chưa có sinh viên. Nhấn Thêm sinh viên để nhập tên đăng nhập.'),
                      for (final s in students)
                        Card(
                            child: ListTile(
                                leading: const CircleAvatar(
                                    child: Icon(Icons.person_outline)),
                                title: Text(s['initials'] ?? s['username']),
                                subtitle:
                                    Text('${s['username']}\n${s['email']}'),
                                trailing: IconButton(
                                    icon: const Icon(
                                        Icons.person_remove_outlined),
                                    onPressed: () async {
                                      if (await confirmDelete(context,
                                          'Gỡ ${s['username']} khỏi lớp?')) {
                                        await run(() => ApiClient.request(
                                            'courses/$cid/students/${s['id']}',
                                            method: 'DELETE'));
                                      }
                                    }))),
                    ],
                    const SizedBox(height: 90),
                  ])),
      floatingActionButton: staff
          ? FloatingActionButton.extended(
              onPressed: () => tab == 0
                  ? editSession()
                  : tab == 1
                      ? manual()
                      : enroll(),
              icon: const Icon(Icons.add),
              label: Text(tab == 0
                  ? 'Thêm buổi'
                  : tab == 1
                      ? 'Bổ sung điểm danh'
                      : 'Thêm sinh viên'))
          : null);
}

class SessionQrScreen extends StatefulWidget {
  final Map<String, dynamic> session, course;
  const SessionQrScreen(
      {super.key, required this.session, required this.course});
  @override
  State<SessionQrScreen> createState() => _SessionQrScreenState();
}

class _SessionQrScreenState extends State<SessionQrScreen> {
  String? token, error;
  Timer? timer;
  int seconds = 0;
  bool fetching = false, saving = false;
  DateTime lastAttempt = DateTime.fromMillisecondsSinceEpoch(0);
  @override
  void initState() {
    super.initState();
    refresh();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() => seconds = token == null
            ? 0
            : (int.parse(token!.split('|')[2]) -
                    DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000)
                .clamp(0, 120));
        if (seconds <= 15 &&
            !fetching &&
            !saving &&
            DateTime.now().difference(lastAttempt).inSeconds >= 10) {
          refresh();
        }
      }
    });
  }

  Future<void> refresh() async {
    if (fetching) return;
    lastAttempt = DateTime.now();
    fetching = true;
    try {
      final d = await ApiClient.request('sessions/${widget.session['id']}/qr');
      if (mounted) {
        setState(() {
          token = d['token'];
          seconds = (int.parse(token!.split('|')[2]) -
                  DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000)
              .clamp(0, 120);
          error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          error = e.toString();
          token = null;
          seconds = 0;
        });
      }
    } finally {
      fetching = false;
    }
  }

  Future<void> saveImage() async {
    if (saving || fetching) return;
    setState(() => saving = true);
    try {
      await refresh();
      final value = token;
      if (value == null || seconds <= 0) return;
      final recorder = ui.PictureRecorder();
      final canvas = Canvas(recorder);
      canvas.drawColor(Colors.white, BlendMode.src);
      canvas.translate(128, 128);
      QrPainter(data: value, version: QrVersions.auto, gapless: true)
          .paint(canvas, const Size(768, 768));
      final picture = recorder.endRecording();
      final image = await picture.toImage(1024, 1024);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      picture.dispose();
      if (data == null) throw StateError('Cannot encode QR image');
      final path = await const MethodChannel('attendance/device')
          .invokeMethod<String>('saveQrImage', {
        'bytes':
            data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        'name':
            'LeDangHoangViet_QR_buoi_${widget.session['id']}_${DateTime.now().millisecondsSinceEpoch}.png',
      });
      if (mounted && path != null) {
        message(context, 'Đã lưu: $path. Ảnh QR vẫn hết hạn theo mã hiển thị.');
      }
    } catch (_) {
      if (mounted) {
        message(
            context, 'Không lưu được ảnh QR. Hãy thử tạo mã mới rồi lưu lại.');
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('QR điểm danh')),
      body: Center(
          child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                Text(widget.course['name'],
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(
                    'Buổi #${widget.session['id']} • ${widget.course['room']}'),
                const SizedBox(height: 24),
                if (token != null && seconds > 0)
                  Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24)),
                      child: QrImageView(data: token!, size: 260)),
                const SizedBox(height: 16),
                Text(error ?? 'Mã còn hiệu lực $seconds giây • tự làm mới',
                    textAlign: TextAlign.center),
                const SizedBox(height: 16),
                const Text(
                    'Sinh viên quét mã và chia sẻ vị trí trong bán kính lớp. Mỗi sinh viên chỉ có một bản ghi trong một buổi.',
                    textAlign: TextAlign.center),
                const SizedBox(height: 20),
                OutlinedButton.icon(
                    onPressed: fetching ? null : refresh,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Tạo mã mới')),
                const SizedBox(height: 12),
                FilledButton.icon(
                    onPressed: saving || fetching ? null : saveImage,
                    icon: const Icon(Icons.save_alt),
                    label: Text(saving ? 'Đang lưu…' : 'Lưu ảnh QR')),
                const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                        'Ảnh được lưu vào Pictures/LeDangHoangViet. Mã có hạn tối đa 2 phút; vị trí vẫn được kiểm tra khi điểm danh.',
                        textAlign: TextAlign.center))
              ]))));
}
