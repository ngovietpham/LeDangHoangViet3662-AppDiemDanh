import '../utils/api_client.dart';

class AuthService {
  Future<Map<String, dynamic>> login(String username, String password,
      {required String otp}) async {
    final data = Map<String, dynamic>.from(await ApiClient.request(
        'Authenticate/login',
        method: 'POST',
        body: {'username': username, 'password': password, 'otp': otp}));
    ApiClient.token = data['token'];
    ApiClient.user = Map<String, dynamic>.from(data['user']);
    return data;
  }
}
