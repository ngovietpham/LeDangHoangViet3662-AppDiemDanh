import 'package:flutter_dotenv/flutter_dotenv.dart';

class ConfigUrl {
  static String? overrideUrl;
  static String get baseUrl {
    const defined = String.fromEnvironment('API_BASE_URL');
    final raw = overrideUrl ??
        (defined.isNotEmpty
            ? defined
            : dotenv.isInitialized
                ? dotenv.env['BASE_URL']
                : null) ??
        'http://10.0.2.2:5300/api/';
    return raw.endsWith('/') ? raw : '$raw/';
  }
}
