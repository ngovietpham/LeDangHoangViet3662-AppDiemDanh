﻿param([switch]$EmailOtp, [string]$DemoPassword='Demo@2026!')
$ErrorActionPreference='Stop'
$projectPath=Join-Path $PSScriptRoot 'ledanghoangviet3662'
if(!(Test-Path -LiteralPath (Join-Path $projectPath 'appsettings.json'))) {
    Copy-Item -LiteralPath (Join-Path $projectPath 'appsettings.example.json') -Destination (Join-Path $projectPath 'appsettings.json')
}
Push-Location $projectPath
try {
    $env:ASPNETCORE_ENVIRONMENT='Development'
    # A fresh local SQLite database; does not modify the existing SQL Server database.
    dotnet run --no-launch-profile -- --urls http://0.0.0.0:5300 --Database:Provider=Sqlite --Demo:Seed=true "--Demo:ExposeOtp=$(!$EmailOtp)" "--Demo:Password=$DemoPassword"
} finally { Pop-Location }
