import json, urllib.request, urllib.error, datetime as dt, time
import os
base=os.environ.get('ATTEND_TEST_URL','http://127.0.0.1:5300/api/')
count=0
def call(path,method='GET',body=None,token=None,expected=200):
 global count
 req=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),method=method,headers={'Content-Type':'application/json',**({'Authorization':'Bearer '+token} if token else {})})
 try:
  with urllib.request.urlopen(req,timeout=15) as r: status=r.status; raw=r.read()
 except urllib.error.HTTPError as e: status=e.code; raw=e.read()
 try: data=json.loads(raw) if raw else None
 except: data=raw.decode()[:500]
 assert status==expected,(method,path,status,expected,data)
 count+=1
 return data
def login(name):
 credentials={'username':name,'password':'Demo@2026!'}
 otp=call('Authenticate/request-login-otp','POST',credentials)['devOtp']
 return call('Authenticate/login','POST',{**credentials,'otp':otp})
admin=login('admin.demo');teacher=login('gv.demo');student=login('sv.demo')
a,t,s=admin['token'],teacher['token'],student['token']
assert [admin['role'],teacher['role'],student['role']]==['Admin','Teacher','Student']
call('Users',expected=401);call('Users',token=s,expected=403);call('Users',token=t,expected=403)
all_users=call('Users',token=a);assert all('passwordHash' not in u and 'securityStamp' not in u for u in all_users)
call('Authenticate/login','POST',{'username':'sv.demo','password':'Demo@2026!','otp':'000000'},expected=401)
call('courses','POST',{},token=s,expected=403)
stamp=str(int(time.time()))
reg={'username':'test'+stamp,'email':'test'+stamp+'@example.test','initials':'SV '+stamp,'password':'Demo@2026!','role':'Admin'}
otp=call('Authenticate/send-otp','POST',{'email':reg['email']})['devOtp']
call('Authenticate/register-with-otp','POST',{**reg,'otp':otp},expected=400)
call('Authenticate/register-with-otp','POST',{**reg,'role':'Student','otp':otp})
call('Authenticate/register-with-otp','POST',{**reg,'role':'Student','otp':otp},expected=400)
new_student=login(reg['username']);ns=new_student['token']
user=call('Users','POST',{'username':'temp'+stamp,'email':'temp'+stamp+'@example.test','initials':'Temp','password':'Demo@2026!','role':'Student'},token=a)
call('Users/'+user['id'],'PUT',{'username':'temp'+stamp,'email':'temp'+stamp+'@example.test','initials':'Temp Updated','role':'Student'},token=a,expected=204)
call('Users/'+user['id'],'DELETE',token=a,expected=204)
course={'code':'QA'+stamp,'name':'Kiểm thử điểm danh','room':'Lab','teacherId':teacher['user']['id'],'totalSessions':5,'minimumRate':.8,'latitude':10.762622,'longitude':106.660172,'radiusMeters':150}
c=call('courses','POST',course,token=a);cid=c['id']
call('courses/'+str(cid),'PUT',{**course,'name':'Kiểm thử cập nhật'},token=a,expected=204)
call(f'courses/{cid}/students','POST',{'username':'sv.demo'},token=t)
call(f'courses/{cid}/students','POST',{'username':'sv.demo'},token=t,expected=409)
call(f'courses/{cid}/sessions',token=ns,expected=403)
now=dt.datetime.now(dt.timezone.utc)
iso=lambda d:d.isoformat().replace('+00:00','Z')
sess={'courseId':cid,'startsAt':iso(now-dt.timedelta(minutes=2)),'endsAt':iso(now+dt.timedelta(hours=1)),'lateAfterMinutes':15,'isClosed':False}
session=call('sessions','POST',sess,token=t);sid=session['id']
call('sessions','POST',sess,token=t,expected=400)
qr=call(f'sessions/{sid}/qr',token=t)['token']
gps={'qrToken':qr,'latitude':course['latitude'],'longitude':course['longitude'],'accuracy':10,'isMocked':False}
expiry_value=int(qr.split('|')[2]);assert 0 < expiry_value-time.time() <= 120
expired_parts=qr.split('|');expired_parts[2]=str(int(time.time())-1)
call(f'sessions/{sid}/check-in','POST',{**gps,'qrToken':'|'.join(expired_parts)},token=s,expected=400)
wrong_parts=qr.split('|');wrong_parts[1]=str(sid+999)
call(f'sessions/{sid}/check-in','POST',{**gps,'qrToken':'|'.join(wrong_parts)},token=s,expected=400)
call(f'sessions/{sid}/check-in','POST',{**gps,'qrToken':qr[:-2]+'00'},token=s,expected=400)
call(f'sessions/{sid}/check-in','POST',{**gps,'latitude':0},token=s,expected=400)
call(f'sessions/{sid}/check-in','POST',{**gps,'accuracy':300},token=s,expected=400)
call(f'sessions/{sid}/check-in','POST',{**gps,'isMocked':True},token=s,expected=400)
record=call(f'sessions/{sid}/check-in','POST',gps,token=s)
assert record['status']=='Present' and record['distanceMeters']<1
call(f'sessions/{sid}/check-in','POST',gps,token=s,expected=409)
history=call(f'courses/{cid}/attendance',token=s);assert len(history)==1
call(f'attendance/{record["id"]}','PUT',{'sessionId':sid,'studentId':student['user']['id'],'status':'Late','note':'Điều chỉnh sau kiểm tra'},token=t,expected=204)
call(f'attendance/{record["id"]}','DELETE',token=t,expected=204)
manual=call('attendance','POST',{'sessionId':sid,'studentId':student['user']['id'],'status':'Excused','note':'Giấy phép được duyệt'},token=t)
call(f'sessions/{sid}','PUT',{**sess,'isClosed':True},token=t,expected=204)
call(f'sessions/{sid}/qr',token=t,expected=400)
call(f'sessions/{sid}/check-in','POST',gps,token=s,expected=400)
call(f'attendance/{manual["id"]}','DELETE',token=t,expected=204)
call(f'sessions/{sid}','DELETE',token=t,expected=204)
call(f'courses/{cid}/students/{student["user"]["id"]}','DELETE',token=t,expected=204)
call(f'courses/{cid}','DELETE',token=a,expected=204)
print(f'PASS: {count} API checks: OTP/roles/registration/users/classes/enrollment/sessions/QR/GPS/duplicate/manual attendance/deletion.')
