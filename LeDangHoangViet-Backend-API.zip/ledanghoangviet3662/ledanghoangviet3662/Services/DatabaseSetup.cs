using ledanghoangviet3662.models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
namespace ledanghoangviet3662.Services;
public static class DatabaseSetup {
    public static async Task Initialize(IServiceProvider provider,IConfiguration config,IWebHostEnvironment env) {
        using var scope=provider.CreateScope();var db=scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        if(config["Database:Provider"]=="Sqlite")await db.Database.EnsureCreatedAsync();else await db.Database.MigrateAsync();
        var roles=scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();var users=scope.ServiceProvider.GetRequiredService<UserManager<User>>();
        foreach(var role in new[]{"Admin","Teacher","Student"})if(!await roles.RoleExistsAsync(role))await roles.CreateAsync(new(role));
        if(!env.IsDevelopment()||!config.GetValue<bool>("Demo:Seed"))return;
        var password=config["Demo:Password"]??throw new InvalidOperationException("Đặt Demo:Password để tạo tài khoản demo.");
        foreach(var (name,role) in new[]{("admin.demo","Admin"),("gv.demo","Teacher"),("sv.demo","Student")}) {
            if(await users.FindByNameAsync(name)!=null)continue;
            var u=new User{UserName=name,Email=name+"@example.test",EmailConfirmed=true,Initials=role=="Student"?"SV001 • Sinh viên demo":role=="Teacher"?"Giảng viên demo":"Quản trị viên demo"};
            var r=await users.CreateAsync(u,password);if(!r.Succeeded)throw new InvalidOperationException(string.Join(';',r.Errors.Select(e=>e.Description)));
            await users.AddToRoleAsync(u,role);
        }
        if(!await db.Courses.AnyAsync()){
            var teacher=(await users.FindByNameAsync("gv.demo"))!;var student=(await users.FindByNameAsync("sv.demo"))!;
            var c=new Course{Code="MOB101",Name="Phát triển ứng dụng di động",Room="Phòng thực hành A301",TeacherId=teacher.Id,Latitude=10.762622,Longitude=106.660172,TotalSessions=15};db.Add(c);await db.SaveChangesAsync();
            db.Add(new Enrollment{CourseId=c.Id,StudentId=student.Id});db.Add(new ClassSession{CourseId=c.Id,StartsAt=DateTime.UtcNow.AddMinutes(-2),EndsAt=DateTime.UtcNow.AddHours(2)});await db.SaveChangesAsync();
        }
    }
}
