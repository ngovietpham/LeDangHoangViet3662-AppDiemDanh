using System.Security.Cryptography;
using System.Text;
namespace ledanghoangviet3662.Services;
public static class AttendanceRules {
    public static double Distance(double a,double b,double c,double d) {
        double R(double n)=>n*Math.PI/180;
        var h=Math.Pow(Math.Sin(R(c-a)/2),2)+Math.Cos(R(a))*Math.Cos(R(c))*Math.Pow(Math.Sin(R(d-b)/2),2);
        return 6371000*2*Math.Asin(Math.Sqrt(Math.Clamp(h,0,1)));
    }
}
public class QrService(IConfiguration config) {
    public const int LifetimeSeconds = 120;
    private string Sign(string body)=>Convert.ToHexString(HMACSHA256.HashData(Encoding.UTF8.GetBytes(config["JWT:Secret"]!),Encoding.UTF8.GetBytes(body)));
    public string Create(int id,DateTime end) {
        var expiry=Math.Min(DateTimeOffset.UtcNow.ToUnixTimeSeconds()+LifetimeSeconds,new DateTimeOffset(DateTime.SpecifyKind(end,DateTimeKind.Utc)).ToUnixTimeSeconds());
        var body=$"ATTEND|{id}|{expiry}";return body+"|"+Sign(body);
    }
    public bool Valid(string token,int id) {
        var p=token.Split('|');if(p.Length!=4||p[0]!="ATTEND"||p[1]!=id.ToString()||!long.TryParse(p[2],out var expiry))return false;
        var now=DateTimeOffset.UtcNow.ToUnixTimeSeconds();if(expiry<=now||expiry>now+LifetimeSeconds+5)return false;
        var expected=Encoding.UTF8.GetBytes(Sign(string.Join('|',p.Take(3))));
        return CryptographicOperations.FixedTimeEquals(expected,Encoding.UTF8.GetBytes(p[3]));
    }
}
