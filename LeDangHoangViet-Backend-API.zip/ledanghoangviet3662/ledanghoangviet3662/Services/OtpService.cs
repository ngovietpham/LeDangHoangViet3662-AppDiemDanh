using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Net;
using System.Net.Mail;
namespace ledanghoangviet3662.Services;
public class OtpService(IConfiguration config, IWebHostEnvironment env) {
    private sealed class Entry {
        public required byte[] Hash { get; init; }
        public DateTime Expires { get; init; }
        public DateTime Sent { get; init; }
        public int Attempts { get; set; }
    }
    private readonly ConcurrentDictionary<string,Entry> entries = new();
    private string Key(string purpose,string email) => purpose+":"+email.Trim().ToUpperInvariant();
    public async Task<string?> Send(string purpose,string email) {
        var key=Key(purpose,email);
        var code=RandomNumberGenerator.GetInt32(100000,1000000).ToString();
        var entry=new Entry{Hash=SHA256.HashData(Encoding.UTF8.GetBytes(code)),Sent=DateTime.UtcNow,Expires=DateTime.UtcNow.AddMinutes(5)};
        lock(entries) {
            foreach(var old in entries.Where(x=>x.Value.Expires<DateTime.UtcNow).Select(x=>x.Key).ToArray()) entries.TryRemove(old,out _);
            if(entries.TryGetValue(key,out var previous) && previous.Sent.AddSeconds(60)>DateTime.UtcNow) throw new InvalidOperationException("Vui lòng chờ 60 giây trước khi gửi lại OTP.");
            if(entries.Count>=10000) throw new InvalidOperationException("Hệ thống đang bận. Hãy thử lại sau.");
            entries[key]=entry;
        }
        try {
            // Explicit development-only mode for automated tests and classroom demos.
            if(env.IsDevelopment() && config.GetValue<bool>("Demo:ExposeOtp") && email.Trim().EndsWith("@example.test", StringComparison.OrdinalIgnoreCase)) return code;
            var s=config.GetSection("EmailSettings");
            using var client=new SmtpClient(s["Host"],s.GetValue<int>("Port",587)) {Credentials=new NetworkCredential(s["Mail"],s["Password"]),EnableSsl=true,Timeout=15000};
            using var mail=new MailMessage(s["Mail"]!,email,"Attend • Mã xác thực",$"Mã OTP {(purpose=="login"?"đăng nhập":"đăng ký")} của bạn: {code}. Hết hạn sau 5 phút, tối đa 5 lần nhập.");
            await client.SendMailAsync(mail);
            return null;
        } catch { entries.TryRemove(key,out _); throw; }
    }
    public bool Consume(string purpose,string email,string code) {
        lock(entries) {
            var key=Key(purpose,email);
            if(!entries.TryGetValue(key,out var e)) return false;
            if(e.Expires<DateTime.UtcNow || ++e.Attempts>5) {entries.TryRemove(key,out _);return false;}
            if(!CryptographicOperations.FixedTimeEquals(e.Hash,SHA256.HashData(Encoding.UTF8.GetBytes(code)))) return false;
            entries.TryRemove(key,out _); return true;
        }
    }
}
