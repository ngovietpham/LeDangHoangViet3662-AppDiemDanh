﻿namespace ledanghoangviet3662.models // Sửa lại namespace theo project của bạn
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }

        // Mối quan hệ 1-N: 1 Danh mục có nhiều Sản phẩm
        public ICollection<Product>? Products { get; set; }
    }
}