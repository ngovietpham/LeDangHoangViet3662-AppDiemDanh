using System.ComponentModel.DataAnnotations;
namespace ledanghoangviet3662.models;

public class RegisterOtpModel
{
    [Required, MaxLength(100)] public string Username { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, MinLength(8)] public string Password { get; set; } = "";
    [Required, MaxLength(100)] public string Initials { get; set; } = "";
    public string Role { get; set; } = "Student";
    [Required, RegularExpression("^[0-9]{6}$")] public string Otp { get; set; } = "";
}
