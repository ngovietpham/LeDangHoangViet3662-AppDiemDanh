﻿using Microsoft.AspNetCore.Identity;

namespace ledanghoangviet3662.models
{
    public class User : IdentityUser
    {
        public string? Initials { get; set; }
        public string? Role { get; set; }
    }
}