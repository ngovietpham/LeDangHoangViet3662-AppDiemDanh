using System.ComponentModel.DataAnnotations;
namespace ledanghoangviet3662.models;

public class Course
{
    public int Id { get; set; }
    [Required, MaxLength(30)] public string Code { get; set; } = "";
    [Required, MaxLength(150)] public string Name { get; set; } = "";
    [MaxLength(80)] public string Room { get; set; } = "";
    [Required] public string TeacherId { get; set; } = "";
    [Range(1, 200)] public int TotalSessions { get; set; } = 15;
    [Range(.1, 1)] public double MinimumRate { get; set; } = .8;
    [Range(-90, 90)] public double Latitude { get; set; }
    [Range(-180, 180)] public double Longitude { get; set; }
    [Range(20, 2000)] public double RadiusMeters { get; set; } = 150;
}
public class Enrollment
{
    public int CourseId { get; set; }
    public string StudentId { get; set; } = "";
}
public class ClassSession
{
    public int Id { get; set; }
    public int CourseId { get; set; }
    public DateTime StartsAt { get; set; }
    public DateTime EndsAt { get; set; }
    [Range(0, 120)] public int LateAfterMinutes { get; set; } = 15;
    public bool IsClosed { get; set; }
}
public class AttendanceRecord
{
    public int Id { get; set; }
    public int SessionId { get; set; }
    public string StudentId { get; set; } = "";
    public DateTime CheckedAt { get; set; }
    [MaxLength(12)] public string Status { get; set; } = "Present";
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
    public double? DistanceMeters { get; set; }
    [MaxLength(200)] public string Note { get; set; } = "";
}
public class CheckInRequest
{
    [Required] public string QrToken { get; set; } = "";
    [Range(-90, 90)] public double Latitude { get; set; }
    [Range(-180, 180)] public double Longitude { get; set; }
    [Range(0, 2000)] public double Accuracy { get; set; }
    public bool IsMocked { get; set; }
}
public class UserInput
{
    [Required, MaxLength(100)] public string Username { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [MaxLength(100)] public string Initials { get; set; } = "";
    public string Password { get; set; } = "";
    [RegularExpression("^(Admin|Teacher|Student)$")] public string Role { get; set; } = "Student";
}
public class ManualAttendance
{
    public int SessionId { get; set; }
    [Required] public string StudentId { get; set; } = "";
    [RegularExpression("^(Present|Late|Excused|Absent)$")] public string Status { get; set; } = "Present";
    [Required, MaxLength(200)] public string Note { get; set; } = "";
}
