using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
namespace ledanghoangviet3662.models;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext<User>(options)
{
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Course> Courses => Set<Course>();
    public DbSet<Enrollment> Enrollments => Set<Enrollment>();
    public DbSet<ClassSession> Sessions => Set<ClassSession>();
    public DbSet<AttendanceRecord> Attendance => Set<AttendanceRecord>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);
        b.HasDefaultSchema("identity");
        b.Entity<User>().Property(u => u.Initials).HasMaxLength(100);
        b.Entity<Product>().HasOne(p => p.Category).WithMany(c => c.Products).HasForeignKey(p => p.CategoryId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<Course>().HasIndex(c => c.Code).IsUnique();
        b.Entity<Course>().HasOne<User>().WithMany().HasForeignKey(c => c.TeacherId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Enrollment>().HasKey(e => new { e.CourseId, e.StudentId });
        b.Entity<Enrollment>().HasOne<Course>().WithMany().HasForeignKey(e => e.CourseId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<Enrollment>().HasOne<User>().WithMany().HasForeignKey(e => e.StudentId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<ClassSession>().HasOne<Course>().WithMany().HasForeignKey(s => s.CourseId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<AttendanceRecord>().HasIndex(a => new { a.SessionId, a.StudentId }).IsUnique();
        b.Entity<AttendanceRecord>().HasOne<ClassSession>().WithMany().HasForeignKey(a => a.SessionId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<AttendanceRecord>().HasOne<User>().WithMany().HasForeignKey(a => a.StudentId).OnDelete(DeleteBehavior.Restrict);
    }
}
