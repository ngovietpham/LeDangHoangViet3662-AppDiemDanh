﻿namespace ledanghoangviet3662.models
{
    public class Product
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public decimal Price { get; set; }
        public string? Image { get; set; }
        public string? Description { get; set; }

        // --- Cập nhật thêm cho Bài 6 và Bài 8 ---
        public int? CategoryId { get; set; } // Nullable để khi xóa danh mục, giá trị này thành null
        public Category? Category { get; set; }
    }
}