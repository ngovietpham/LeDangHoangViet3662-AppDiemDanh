using System.ComponentModel.DataAnnotations;
namespace ledanghoangviet3662.models;

public class OtpRequestModel
{
    [Required, EmailAddress] public string Email { get; set; } = "";
}
