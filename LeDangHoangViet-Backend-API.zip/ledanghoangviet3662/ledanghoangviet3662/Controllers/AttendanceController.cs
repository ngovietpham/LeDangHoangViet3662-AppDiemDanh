using ledanghoangviet3662.models;
using ledanghoangviet3662.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace ledanghoangviet3662.Controllers;

[ApiController, Route("api"), Authorize]
public class AttendanceController(ApplicationDbContext db, UserManager<User> users, QrService qr) : ControllerBase
{
    string Uid => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Admin => User.IsInRole("Admin");
    bool Staff => Admin || User.IsInRole("Teacher");
    async Task<bool> Manage(int id) => Admin || await db.Courses.AnyAsync(c => c.Id == id && c.TeacherId == Uid);
    async Task<bool> Access(int id) => Staff ? await Manage(id) : await db.Enrollments.AnyAsync(e => e.CourseId == id && e.StudentId == Uid);
    [HttpGet("me")] public async Task<IActionResult> Me() { var u = await users.FindByIdAsync(Uid); return u == null ? Unauthorized() : Ok(new { id = u.Id, username = u.UserName, email = u.Email, initials = u.Initials, role = Admin ? "Admin" : Staff ? "Teacher" : "Student" }); }
    [HttpGet("courses")]
    public async Task<IActionResult> Courses()
    {
        var q = db.Courses.AsNoTracking(); if (!Admin) q = Staff ? q.Where(c => c.TeacherId == Uid) : q.Where(c => db.Enrollments.Any(e => e.CourseId == c.Id && e.StudentId == Uid));
        return Ok(await q.OrderBy(c => c.Code).ToListAsync());
    }
    async Task<string?> ValidateCourse(Course m, int? id = null)
    {
        var teacher = await users.FindByIdAsync(m.TeacherId);
        if (teacher == null || !await users.IsInRoleAsync(teacher, "Teacher")) return "Chọn tài khoản Giảng viên hợp lệ.";
        if (await db.Courses.AnyAsync(c => c.Code == m.Code && c.Id != id)) return "Mã lớp đã tồn tại.";
        if (id != null && await db.Sessions.CountAsync(s => s.CourseId == id) > m.TotalSessions) return "Tổng số buổi không được ít hơn các buổi đã tạo.";
        return null;
    }
    [HttpPost("courses"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateCourse(Course m)
    {
        var error = await ValidateCourse(m); if (error != null) return BadRequest(new { message = error }); m.Id = 0; db.Courses.Add(m); await db.SaveChangesAsync(); return Ok(m);
    }
    [HttpPut("courses/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateCourse(int id, Course m)
    {
        var c = await db.Courses.FindAsync(id); if (c == null) return NotFound(); var error = await ValidateCourse(m, id); if (error != null) return BadRequest(new { message = error }); m.Id = id; db.Entry(c).CurrentValues.SetValues(m); await db.SaveChangesAsync(); return NoContent();
    }
    [HttpDelete("courses/{id:int}"), Authorize(Roles = "Admin")] public async Task<IActionResult> DeleteCourse(int id) { var c = await db.Courses.FindAsync(id); if (c == null) return NotFound(); db.Courses.Remove(c); await db.SaveChangesAsync(); return NoContent(); }
    [HttpGet("courses/{id:int}/students"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Students(int id)
    {
        if (!await Manage(id)) return Forbid();
        return Ok(await (from e in db.Enrollments join u in db.Users on e.StudentId equals u.Id where e.CourseId == id select new { id = u.Id, username = u.UserName, email = u.Email, initials = u.Initials }).ToListAsync());
    }
    [HttpPost("courses/{id:int}/students"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Enroll(int id, EnrollInput m)
    {
        if (!await Manage(id)) return Forbid(); var u = await users.FindByNameAsync(m.Username.Trim());
        if (u == null || !await users.IsInRoleAsync(u, "Student")) return BadRequest(new { message = "Không tìm thấy tài khoản Sinh viên." });
        if (await db.Enrollments.FindAsync(id, u.Id) != null) return Conflict(new { message = "Sinh viên đã có trong lớp." });
        db.Enrollments.Add(new() { CourseId = id, StudentId = u.Id }); await db.SaveChangesAsync(); return Ok(new { message = "Đã thêm sinh viên." });
    }
    [HttpDelete("courses/{id:int}/students/{studentId}"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Unenroll(int id, string studentId)
    {
        if (!await Manage(id)) return Forbid(); if (await db.Attendance.AnyAsync(a => a.StudentId == studentId && db.Sessions.Any(s => s.Id == a.SessionId && s.CourseId == id))) return BadRequest(new { message = "Sinh viên đã có điểm danh trong lớp. Không thể gỡ để tránh mất lịch sử." });
        var e = await db.Enrollments.FindAsync(id, studentId); if (e == null) return NotFound(); db.Remove(e); await db.SaveChangesAsync(); return NoContent();
    }
    [HttpGet("courses/{id:int}/sessions")] public async Task<IActionResult> Sessions(int id) { if (!await Access(id)) return Forbid(); return Ok(await db.Sessions.Where(s => s.CourseId == id).OrderByDescending(s => s.StartsAt).ToListAsync()); }
    async Task<string?> ValidateSession(ClassSession m, int? id = null)
    {
        if (m.StartsAt.Kind != DateTimeKind.Utc || m.EndsAt.Kind != DateTimeKind.Utc) return "Thời gian cần theo chuẩn UTC (đuôi Z).";
        if (m.EndsAt <= m.StartsAt || m.EndsAt - m.StartsAt > TimeSpan.FromHours(12)) return "Giờ kết thúc phải sau giờ bắt đầu, trong vòng 12 giờ.";
        var c = await db.Courses.FindAsync(m.CourseId); if (c == null) return "Không tìm thấy lớp.";
        if (id == null && await db.Sessions.CountAsync(s => s.CourseId == m.CourseId) >= c.TotalSessions) return "Đã đủ tổng số buổi dự kiến.";
        if (await db.Sessions.AnyAsync(s => s.CourseId == m.CourseId && s.Id != id && s.StartsAt < m.EndsAt && s.EndsAt > m.StartsAt)) return "Buổi học bị trùng thời gian."; return null;
    }
    [HttpPost("sessions"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> CreateSession(ClassSession m)
    {
        if (!await Manage(m.CourseId)) return Forbid(); var e = await ValidateSession(m); if (e != null) return BadRequest(new { message = e }); m.Id = 0; db.Sessions.Add(m); await db.SaveChangesAsync(); return Ok(m);
    }
    [HttpPut("sessions/{id:int}"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> UpdateSession(int id, ClassSession m)
    {
        var s = await db.Sessions.FindAsync(id); if (s == null) return NotFound(); if (!await Manage(s.CourseId) || s.CourseId != m.CourseId) return Forbid();
        var e = await ValidateSession(m, id); if (e != null) return BadRequest(new { message = e }); m.Id = id; db.Entry(s).CurrentValues.SetValues(m); await db.SaveChangesAsync(); return NoContent();
    }
    [HttpDelete("sessions/{id:int}"), Authorize(Roles = "Admin,Teacher")] public async Task<IActionResult> DeleteSession(int id) { var s = await db.Sessions.FindAsync(id); if (s == null) return NotFound(); if (!await Manage(s.CourseId)) return Forbid(); db.Remove(s); await db.SaveChangesAsync(); return NoContent(); }
    [HttpGet("sessions/{id:int}/qr"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> GetQr(int id)
    {
        var s = await db.Sessions.FindAsync(id); if (s == null) return NotFound(); if (!await Manage(s.CourseId)) return Forbid();
        if (s.IsClosed || DateTime.UtcNow < s.StartsAt || DateTime.UtcNow > s.EndsAt) return BadRequest(new { message = "Buổi học chưa mở hoặc đã kết thúc." });
        var token = qr.Create(id, s.EndsAt);
        var remaining = long.Parse(token.Split('|')[2]) - DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        return Ok(new { token, validForSeconds = Math.Max(0, remaining) });
    }
    [HttpPost("sessions/{id:int}/check-in"), Authorize(Roles = "Student")]
    public async Task<IActionResult> CheckIn(int id, CheckInRequest m)
    {
        var s = await db.Sessions.FindAsync(id); if (s == null) return NotFound(); if (!await Access(s.CourseId)) return Forbid();
        if (s.IsClosed || DateTime.UtcNow < s.StartsAt || DateTime.UtcNow > s.EndsAt) return BadRequest(new { message = "Buổi học chưa mở hoặc đã kết thúc." });
        if (!qr.Valid(m.QrToken, id)) return BadRequest(new { message = "QR sai hoặc hết hạn. Hãy quét mã mới trên màn hình giảng viên." });
        var c = (await db.Courses.FindAsync(s.CourseId))!;
        if (m.IsMocked || !double.IsFinite(m.Accuracy) || m.Accuracy > Math.Min(c.RadiusMeters, 100)) return BadRequest(new { message = "Vị trí giả lập hoặc GPS chưa đủ chính xác. Thử lại ngoài vùng che khuất." });
        var distance = AttendanceRules.Distance(c.Latitude, c.Longitude, m.Latitude, m.Longitude);
        if (!double.IsFinite(distance) || distance > c.RadiusMeters) return BadRequest(new { message = $"Bạn cách lớp {distance:F0} m, vượt bán kính {c.RadiusMeters:F0} m." });
        if (await db.Attendance.AnyAsync(a => a.SessionId == id && a.StudentId == Uid)) return Conflict(new { message = "Bạn đã được điểm danh ở buổi học này." });
        var a = new AttendanceRecord { SessionId = id, StudentId = Uid, CheckedAt = DateTime.UtcNow, Status = DateTime.UtcNow > s.StartsAt.AddMinutes(s.LateAfterMinutes) ? "Late" : "Present", Latitude = m.Latitude, Longitude = m.Longitude, DistanceMeters = distance };
        db.Attendance.Add(a); try { await db.SaveChangesAsync(); } catch (DbUpdateException) { return Conflict(new { message = "Điểm danh đã được ghi nhận. Hãy tải lại." }); }
        return Ok(a);
    }
    [HttpGet("courses/{id:int}/attendance")]
    public async Task<IActionResult> Records(int id)
    {
        if (!await Access(id)) return Forbid();
        return Ok(await (from a in db.Attendance join s in db.Sessions on a.SessionId equals s.Id join u in db.Users on a.StudentId equals u.Id where s.CourseId == id && (Staff || a.StudentId == Uid) orderby a.CheckedAt descending select new { a.Id, a.SessionId, a.StudentId, a.Status, a.CheckedAt, a.DistanceMeters, a.Note, username = u.UserName, initials = u.Initials, startsAt = s.StartsAt }).ToListAsync());
    }
    [HttpPost("attendance"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> AddRecord(ManualAttendance m)
    {
        var s = await db.Sessions.FindAsync(m.SessionId); if (s == null) return NotFound(); if (!await Manage(s.CourseId)) return Forbid();
        if (!await db.Enrollments.AnyAsync(e => e.CourseId == s.CourseId && e.StudentId == m.StudentId)) return BadRequest(new { message = "Sinh viên chưa được thêm vào lớp." });
        if (await db.Attendance.AnyAsync(a => a.SessionId == m.SessionId && a.StudentId == m.StudentId)) return Conflict(new { message = "Đã có bản ghi. Hãy dùng chức năng sửa." });
        var a = new AttendanceRecord { SessionId = m.SessionId, StudentId = m.StudentId, Status = m.Status, Note = m.Note.Trim(), CheckedAt = DateTime.UtcNow }; db.Add(a); await db.SaveChangesAsync(); return Ok(a);
    }
    [HttpPut("attendance/{id:int}"), Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> EditRecord(int id, ManualAttendance m)
    {
        var a = await db.Attendance.FindAsync(id); if (a == null) return NotFound(); var s = (await db.Sessions.FindAsync(a.SessionId))!; if (!await Manage(s.CourseId)) return Forbid();
        a.Status = m.Status; a.Note = m.Note.Trim(); await db.SaveChangesAsync(); return NoContent();
    }
    [HttpDelete("attendance/{id:int}"), Authorize(Roles = "Admin,Teacher")] public async Task<IActionResult> DeleteRecord(int id) { var a = await db.Attendance.FindAsync(id); if (a == null) return NotFound(); var s = (await db.Sessions.FindAsync(a.SessionId))!; if (!await Manage(s.CourseId)) return Forbid(); db.Remove(a); await db.SaveChangesAsync(); return NoContent(); }
}
public class EnrollInput { [System.ComponentModel.DataAnnotations.Required] public string Username { get; set; } = ""; }
