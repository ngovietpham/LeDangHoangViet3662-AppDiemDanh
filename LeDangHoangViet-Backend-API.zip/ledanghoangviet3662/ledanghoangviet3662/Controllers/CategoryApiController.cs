﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ledanghoangviet3662.models;
using ledanghoangviet3662.Repositories;

namespace ledanghoangviet3662.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryApiController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryApiController(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        // Ai cũng có thể xem danh sách danh mục (Hoặc bạn có thể thêm [Authorize] nếu muốn chặn)
        [HttpGet]
        public async Task<IActionResult> GetCategories()
        {
            return Ok(await _categoryRepository.GetCategoriesAsync());
        }

        // CHỈ ADMIN MỚI ĐƯỢC THÊM
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddCategory([FromBody] Category category)
        {
            await _categoryRepository.AddCategoryAsync(category);
            return Ok(new { Status = true, Message = "Category added successfully" });
        }

        // CHỈ ADMIN MỚI ĐƯỢC SỬA
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] Category category)
        {
            if (id != category.Id) return BadRequest();
            await _categoryRepository.UpdateCategoryAsync(category);
            return Ok(new { Status = true, Message = "Category updated successfully" });
        }

        // CHỈ ADMIN MỚI ĐƯỢC XÓA
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            await _categoryRepository.DeleteCategoryAsync(id);
            return Ok(new { Status = true, Message = "Category deleted successfully" });
        }
    }
}