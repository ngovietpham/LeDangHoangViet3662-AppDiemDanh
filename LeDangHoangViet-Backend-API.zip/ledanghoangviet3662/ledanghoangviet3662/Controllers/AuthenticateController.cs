using ledanghoangviet3662.models;
using ledanghoangviet3662.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
namespace ledanghoangviet3662.Controllers;

[ApiController, Route("api/[controller]"), AllowAnonymous, EnableRateLimiting("auth")]
public class AuthenticateController(UserManager<User> users, OtpService otp, IConfiguration config, ILogger<AuthenticateController> logger) : ControllerBase
{
    [HttpPost("send-otp")]
    public async Task<IActionResult> Send(OtpRequestModel m)
    {
        if (await users.FindByEmailAsync(m.Email.Trim()) != null) return BadRequest(new { message = "Email đã được sử dụng." });
        return await Deliver("register", m.Email.Trim());
    }
    private async Task<IActionResult> Deliver(string purpose, string email)
    {
        try { var dev = await otp.Send(purpose, email); return Ok(new { status = true, message = dev == null ? "Đã gửi OTP qua email. Mã có hiệu lực 5 phút." : "Chế độ DEMO: OTP hiển thị trên màn hình, không gửi email.", devOtp = dev }); }
        catch (InvalidOperationException e) { return StatusCode(429, new { message = e.Message }); }
        catch (Exception e) { logger.LogError(e, "SMTP delivery failed"); return StatusCode(503, new { message = "Chưa gửi được email. Kiểm tra cấu hình SMTP trên server." }); }
    }
    [HttpPost("register-with-otp")]
    public async Task<IActionResult> Register(RegisterOtpModel m)
    {
        if (m.Role != "Student") return BadRequest(new { message = "Tài khoản tự đăng ký chỉ có quyền Sinh viên. Admin cấp quyền giảng viên." });
        if (await users.FindByNameAsync(m.Username.Trim()) != null || await users.FindByEmailAsync(m.Email.Trim()) != null) return BadRequest(new { message = "Tên đăng nhập hoặc email đã tồn tại." });
        var user = new User { UserName = m.Username.Trim(), Email = m.Email.Trim(), Initials = m.Initials.Trim(), EmailConfirmed = true };
        foreach (var validator in users.PasswordValidators)
        {
            var v = await validator.ValidateAsync(users, user, m.Password);
            if (!v.Succeeded) return BadRequest(new { message = string.Join("; ", v.Errors.Select(x => x.Description)) });
        }
        if (!otp.Consume("register", m.Email, m.Otp)) return BadRequest(new { message = "OTP sai, hết hạn hoặc đã dùng. Hãy yêu cầu mã mới." });
        var result = await users.CreateAsync(user, m.Password);
        if (!result.Succeeded) return BadRequest(new { message = string.Join("; ", result.Errors.Select(x => x.Description)) });
        await users.AddToRoleAsync(user, "Student");
        return Ok(new { status = true, message = "Đăng ký thành công. Hãy đăng nhập." });
    }
    [HttpPost("request-login-otp")]
    public async Task<IActionResult> RequestLogin(LoginModel m)
    {
        var user = await ValidatePassword(m);
        if (user == null) return Unauthorized(new { message = "Sai tài khoản, mật khẩu hoặc tài khoản đang bị khóa." });
        if (string.IsNullOrEmpty(user.Email)) return BadRequest(new { message = "Tài khoản chưa có email. Liên hệ quản trị viên." });
        return await Deliver("login", user.Email);
    }
    private async Task<User?> ValidatePassword(LoginModel m)
    {
        var u = await users.FindByNameAsync(m.Username.Trim());
        if (u == null || await users.IsLockedOutAsync(u)) return null;
        if (!await users.CheckPasswordAsync(u, m.Password)) { await users.AccessFailedAsync(u); return null; }
        return u;
    }
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginModel m)
    {
        var u = await ValidatePassword(m);
        if (u == null) return Unauthorized(new { message = "Sai tài khoản, mật khẩu hoặc tài khoản đang bị khóa." });
        if (!otp.Consume("login", u.Email ?? "", m.Otp)) { await users.AccessFailedAsync(u); return Unauthorized(new { message = "OTP sai, hết hạn hoặc đã dùng." }); }
        await users.ResetAccessFailedCountAsync(u);
        var roles = await users.GetRolesAsync(u);
        var role = roles.Contains("Admin") ? "Admin" : roles.Contains("Teacher") ? "Teacher" : "Student";
        var claims = new[] { new Claim(ClaimTypes.NameIdentifier, u.Id), new Claim(ClaimTypes.Name, u.UserName!), new Claim(ClaimTypes.Role, role), new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()) };
        var token = new JwtSecurityToken(config["JWT:ValidIssuer"], config["JWT:ValidAudience"], claims, expires: DateTime.UtcNow.AddHours(3), signingCredentials: new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["JWT:Secret"]!)), SecurityAlgorithms.HmacSha256));
        return Ok(new { status = true, token = new JwtSecurityTokenHandler().WriteToken(token), role, user = new { id = u.Id, username = u.UserName, email = u.Email, initials = u.Initials, role } });
    }
}
