using ledanghoangviet3662.models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace ledanghoangviet3662.Controllers;

[ApiController, Route("api/Users"), Authorize(Roles = "Admin")]
public class UsersController(UserManager<User> users, ApplicationDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List()
    {
        var result = new List<object>();
        foreach (var u in await users.Users.OrderBy(x => x.UserName).ToListAsync()) result.Add(new { id = u.Id, username = u.UserName, email = u.Email, initials = u.Initials, role = (await users.GetRolesAsync(u)).FirstOrDefault() ?? "Student" });
        return Ok(result);
    }
    [HttpPost]
    public async Task<IActionResult> Create(UserInput m)
    {
        var u = new User { UserName = m.Username.Trim(), Email = m.Email.Trim(), Initials = m.Initials, EmailConfirmed = true };
        var r = await users.CreateAsync(u, m.Password);
        if (!r.Succeeded) return BadRequest(new { message = string.Join("; ", r.Errors.Select(e => e.Description)) });
        await users.AddToRoleAsync(u, m.Role); return Ok(new { id = u.Id });
    }
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(string id, UserInput m)
    {
        var u = await users.FindByIdAsync(id); if (u == null) return NotFound();
        if (id == User.FindFirstValue(ClaimTypes.NameIdentifier) && m.Role != "Admin") return BadRequest(new { message = "Không thể tự bỏ quyền quản trị." });
        if (m.Role != "Teacher" && await db.Courses.AnyAsync(c => c.TeacherId == id)) return BadRequest(new { message = "Hãy chuyển lớp cho giảng viên khác trước khi đổi vai trò." });
        if (m.Role != "Student" && await db.Enrollments.AnyAsync(e => e.StudentId == id)) return BadRequest(new { message = "Hãy xóa đăng ký lớp trước khi đổi vai trò sinh viên." });
        u.UserName = m.Username.Trim(); u.Email = m.Email.Trim(); u.Initials = m.Initials;
        var r = await users.UpdateAsync(u); if (!r.Succeeded) return BadRequest(new { message = string.Join("; ", r.Errors.Select(e => e.Description)) });
        await users.RemoveFromRolesAsync(u, await users.GetRolesAsync(u)); await users.AddToRoleAsync(u, m.Role); return NoContent();
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        if (id == User.FindFirstValue(ClaimTypes.NameIdentifier)) return BadRequest(new { message = "Không thể xóa chính mình." });
        var u = await users.FindByIdAsync(id); if (u == null) return NotFound();
        if (await db.Courses.AnyAsync(c => c.TeacherId == id) || await db.Attendance.AnyAsync(a => a.StudentId == id) || await db.Enrollments.AnyAsync(e => e.StudentId == id)) return BadRequest(new { message = "Tài khoản có dữ liệu học tập. Gỡ liên kết trước khi xóa." });
        var r = await users.DeleteAsync(u); return r.Succeeded ? NoContent() : BadRequest(new { message = "Không thể xóa tài khoản." });
    }
}
