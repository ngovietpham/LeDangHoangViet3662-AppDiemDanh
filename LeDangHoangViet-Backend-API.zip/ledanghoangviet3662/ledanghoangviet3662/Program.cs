using ledanghoangviet3662.models;
using ledanghoangviet3662.Services;
using ledanghoangviet3662.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Threading.RateLimiting;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<ApplicationDbContext>(o =>
{
    if (builder.Configuration["Database:Provider"] == "Sqlite") o.UseSqlite(builder.Configuration["Database:SqliteConnection"] ?? "Data Source=ledanghoangviet3662.db");
    else o.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});
builder.Services.AddIdentity<User, IdentityRole>(o => { o.User.RequireUniqueEmail = true; o.Password.RequiredLength = 8; o.Lockout.MaxFailedAccessAttempts = 5; o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(10); }).AddEntityFrameworkStores<ApplicationDbContext>().AddDefaultTokenProviders();
builder.Services.AddAuthentication(o => { o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme; o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme; o.DefaultForbidScheme = JwtBearerDefaults.AuthenticationScheme; }).AddJwtBearer(o =>
{
    o.TokenValidationParameters = new() { ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true, ValidIssuer = builder.Configuration["JWT:ValidIssuer"], ValidAudience = builder.Configuration["JWT:ValidAudience"], IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Secret"] ?? throw new InvalidOperationException("Thiếu JWT:Secret"))), ClockSkew = TimeSpan.FromSeconds(15) };
    // A role change or deleted account invalidates old permissions immediately.
    o.Events = new JwtBearerEvents
    {
        OnTokenValidated = async ctx =>
        {
            var manager = ctx.HttpContext.RequestServices.GetRequiredService<UserManager<User>>();
            var id = ctx.Principal?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value; var role = ctx.Principal?.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            var u = id == null ? null : await manager.FindByIdAsync(id);
            if (u == null || role == null || !await manager.IsInRoleAsync(u, role) || await manager.IsLockedOutAsync(u)) ctx.Fail("Tài khoản hoặc quyền đã thay đổi.");
        }
    };
});
builder.Services.AddAuthorization(o => o.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());
builder.Services.AddRateLimiter(o => { o.RejectionStatusCode = 429; o.AddPolicy("auth", ctx => RateLimitPartition.GetFixedWindowLimiter(ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown", _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 })); });
builder.Services.AddSingleton<OtpService>(); builder.Services.AddSingleton<QrService>();
builder.Services.AddScoped<IProductRepository, ProductRepository>(); builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddControllers(); builder.Services.AddEndpointsApiExplorer(); builder.Services.AddSwaggerGen();
var app = builder.Build();
if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); } else app.UseHttpsRedirection();
app.UseRateLimiter(); app.UseAuthentication(); app.UseAuthorization(); app.MapControllers(); app.MapGet("/health", () => Results.Ok(new { status = "ok" })).AllowAnonymous();
await DatabaseSetup.Initialize(app.Services, app.Configuration, app.Environment);
app.Run();
public partial class Program { }
